# AgriTrade Pro (Prompt Challenge)

A multilingual AI assistant designed for agricultural market vendors across India. This application enables voice-based trade negotiations, automatic data extraction, and digital documentation to streamline agricultural trading processes while supporting multiple Indian languages.

## 🚀 Live Demo

**Try the application online:** [https://agritrade-pro.streamlit.app](https://agritrade-pro.streamlit.app)

*Note: Replace with your actual Streamlit Cloud deployment URL*

## Features

- **Voice-First Interface**: Natural voice-based negotiations in multiple Indian languages
- **Multilingual Support**: Hindi, Tamil, Telugu, Bengali, Marathi, Gujarati, and English
- **AI-Powered Analytics**: Real-time market insights, price predictions, and trend analysis
- **Trade Management**: Digital trade ledger with comprehensive analytics
- **Professional UI**: Enterprise-grade interface with advanced animations and responsive design
- **Market Intelligence**: Live market alerts, price forecasting, and trading recommendations
- **Export Capabilities**: Comprehensive analytics reports and data export functionality

## Quick Start

### Prerequisites

- Python 3.8 or higher
- Google Gemini API key (for AI processing)
- Modern web browser (Chrome, Firefox, Safari, Edge)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/prompt-challenge.git
   cd prompt-challenge
   ```

2. **Create and activate virtual environment**
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   # Copy the template
   cp .env.template .env
   
   # Edit .env file and add your Gemini API key
   # GEMINI_API_KEY=your_gemini_api_key_here
   ```

5. **Run the application**
   ```bash
   streamlit run app.py
   ```

6. **Open your browser**
   Navigate to `http://localhost:8501` to access the application.

## Demo Guide

### Getting Started
1. **Language Selection**: Use the language selector in the sidebar to choose your preferred language
2. **Quick Demo**: Click "Quick Demo" button to load sample trade data and conversations
3. **Sample Data**: Use "Add Sample Data" to generate random trade records for testing

### Core Features
1. **Trade Negotiation**
   - Click "Start Negotiation" to begin a new trade session
   - Use voice recording simulation to process trade commands
   - View extracted data and conversation history

2. **Advanced AI Features**
   - **Price Prediction**: AI-powered market forecasting with confidence levels
   - **Market Trends**: Real-time analysis of trending products and market conditions
   - **Voice Simulation**: Interactive voice command processing with intelligent responses

3. **Trade Analytics**
   - View comprehensive trade statistics and performance metrics
   - Analyze product performance and profit margins
   - Export detailed analytics reports

4. **Market Insights**
   - Live market alerts and opportunities
   - Price trend analysis and recommendations
   - Trading strategy suggestions

### Voice Commands (Simulation)
The application simulates voice processing for the following types of commands:
- Trade requests: "Potato 50 kg at 25 rupees per kg"
- Price queries: "What is the current rice price?"
- Market analysis: "Show me today's market trends"
- Calculations: "Calculate profit for 100kg potato"

## 📁 Project Structure

```
prompt-challenge/
├── 📄 app.py                           # Main Streamlit application entry point
├── 📄 requirements.txt                 # Python dependencies for production
├── 📄 requirements-dev.txt             # Development dependencies
├── 📄 .env.template                    # Environment variables template
├── 📄 .gitignore                       # Git ignore rules
├── 📄 README.md                        # Project documentation (this file)
├── 📄 LICENSE                          # MIT License
├── 📄 CHANGELOG.md                     # Version history and changes
├── 📄 CONTRIBUTING.md                  # Contribution guidelines
├── 📄 DEPLOYMENT.md                    # Deployment instructions
├── 📄 setup.py                         # Package configuration
├── 📄 Dockerfile                       # Docker container configuration
├── 📄 docker-compose.yml               # Docker Compose setup
├── 📄 health_check.py                  # Application health monitoring
├── 📄 demo_script.py                   # Demo automation script
├── 📄 .pre-commit-config.yaml          # Code quality hooks
│
├── 📁 .kiro/                           # Kiro IDE specifications
│   ├── 📁 settings/
│   │   └── 📄 mcp.json                 # MCP server configuration
│   └── 📁 specs/
│       └── 📁 prompt-challenge/        # Project specifications
│           ├── 📄 requirements.md      # Detailed requirements document
│           ├── 📄 design.md           # Technical design document
│           └── 📄 tasks.md            # Implementation task list
│
├── 📁 .github/                         # GitHub Actions CI/CD
│   └── 📁 workflows/
│       └── 📄 ci.yml                   # Continuous integration pipeline
│
├── 📁 config/                          # Configuration management
│   ├── 📄 __init__.py
│   └── 📄 settings.py                  # Application configuration
│
├── 📁 src/                             # Source code modules
│   ├── 📄 __init__.py
│   └── 📁 mandi_setu/                  # Main application package
│       ├── 📄 __init__.py
│       ├── 📁 ai/                      # AI processing components
│       │   ├── 📄 __init__.py
│       │   ├── 📄 negotiation_agent.py # AI conversation processing
│       │   └── 📄 price_predictor.py   # Market price prediction
│       ├── 📁 components/              # Reusable UI components
│       │   ├── 📄 __init__.py
│       │   ├── 📄 trade_card.py        # Trade display components
│       │   └── 📄 analytics_dashboard.py # Analytics visualization
│       ├── 📁 database/                # Data persistence layer
│       │   ├── 📄 __init__.py
│       │   ├── 📄 manager.py           # Database operations
│       │   └── 📄 models.py            # Database schema
│       ├── 📁 models/                  # Data models and validation
│       │   ├── 📄 __init__.py
│       │   └── 📄 core.py              # Pydantic data models
│       ├── 📁 theme/                   # UI theming and styling
│       │   ├── 📄 __init__.py
│       │   └── 📄 theme_manager.py     # Viksit Bharat theme
│       ├── 📁 ui/                      # User interface components
│       │   ├── 📄 __init__.py
│       │   ├── 📄 language_manager.py  # Multilingual support
│       │   └── 📄 sidebar.py           # Sidebar components
│       └── 📁 voice/                   # Voice processing
│           ├── 📄 __init__.py
│           └── 📄 interface.py         # Voice recording simulation
│
├── 📁 tests/                           # Test suite
│   ├── 📄 __init__.py
│   ├── 📄 test_app.py                  # Main application tests
│   ├── 📄 test_setup.py                # Setup and configuration tests
│   ├── 📄 test_database_manager.py     # Database operation tests
│   ├── 📄 test_calculation_properties.py # Mathematical calculation tests
│   └── 📄 test_digital_parchi_properties.py # Property-based tests
│
├── 📁 data/                            # Database storage (SQLite)
│   └── 📄 .gitkeep                     # Keep directory in git
│
└── 📁 docs/                            # Additional documentation
    ├── 📄 DEMO_GUIDE.md                # Interactive demo guide
    └── 📄 ADVANCED_DEMO_GUIDE.md       # Advanced features guide
```

### 🔍 Key Components Explained

- **`.kiro/`**: Contains complete Kiro IDE specifications including requirements, design, and implementation tasks
- **`src/mandi_setu/`**: Main application package with modular architecture
- **`config/`**: Centralized configuration management
- **`tests/`**: Comprehensive test suite including property-based tests
- **`.github/workflows/`**: CI/CD pipeline for automated testing and deployment
- **Docker files**: Container configuration for easy deployment

## Project Structure

```
agritrade-pro/
├── app.py                      # Main Streamlit application
├── requirements.txt            # Python dependencies
├── .env.template              # Environment variables template
├── .gitignore                 # Git ignore rules
├── README.md                  # This documentation
├── LICENSE                    # MIT License
├── config/
│   ├── __init__.py
│   └── settings.py            # Configuration management
├── src/
│   └── mandi_setu/
│       ├── __init__.py
│       ├── models/           # Data models and core logic
│       ├── ui/               # User interface components
│       └── theme/            # Theme and styling management
├── tests/                    # Test files
├── data/                    # SQLite database storage
└── docs/                    # Additional documentation
```

## Configuration

The application uses environment variables for configuration:

### Required
- `GEMINI_API_KEY`: Your Google Gemini API key (required for AI features)

### Optional
- `USE_DYNAMODB`: Set to `true` for production DynamoDB usage (default: `false`)
- `AWS_REGION`: AWS region for DynamoDB (default: `us-east-1`)
- `ENVIRONMENT`: Application environment (`development` or `production`)
- `DEBUG`: Enable debug mode (`true` or `false`)

## Supported Languages

- **Hindi** (हिंदी) - Primary Indian language support
- **Tamil** (தமிழ்) - South Indian language support
- **Telugu** (తెలుగు) - Andhra Pradesh and Telangana
- **Bengali** (বাংলা) - West Bengal and Bangladesh
- **Marathi** (मराठी) - Maharashtra state language
- **Gujarati** (ગુજરાતી) - Gujarat state language
- **English** - International and fallback language

## Development

### Running Tests

```bash
# Install test dependencies
pip install pytest pytest-cov hypothesis

# Run tests
pytest tests/

# Run with coverage
pytest --cov=src tests/
```

### Code Quality

```bash
# Install development dependencies
pip install black flake8 mypy

# Format code
black src/ tests/ *.py

# Check style
flake8 src/ tests/ *.py

# Type checking
mypy src/
```

### Adding New Features

1. Create feature branch from main
2. Implement feature with tests
3. Update documentation
4. Submit pull request

## Database

### Development (SQLite)
- Database file: `data/mandi_setu.db`
- Automatically created on first run
- Suitable for local development and testing

### Production (DynamoDB)
- Table name: `mandi-setu-parchis`
- Requires AWS credentials and permissions
- Set `USE_DYNAMODB=true` in environment

## Security

- API keys stored securely in environment variables
- Input validation prevents injection attacks
- Database connections use proper authentication
- HTTPS recommended for production deployment
- No sensitive data stored in version control

## Deployment

### 🌐 Getting Your Hosted Link

#### Option 1: Streamlit Cloud (Recommended - Free)
1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Deploy to Streamlit Cloud**
   - Visit [share.streamlit.io](https://share.streamlit.io)
   - Connect your GitHub account
   - Select your repository
   - Set main file as `app.py`
   - Add environment variables (GEMINI_API_KEY)
   - Click "Deploy"

3. **Get Your Live URL**
   - Your app will be available at: `https://your-app-name.streamlit.app`
   - Share this URL for testing and demos

#### Option 2: Heroku
1. **Install Heroku CLI**
2. **Create Procfile**
   ```
   web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
   ```
3. **Deploy**
   ```bash
   heroku create your-app-name
   heroku config:set GEMINI_API_KEY=your_key_here
   git push heroku main
   ```

### Local Development
```bash
streamlit run app.py --server.port 8501
```

### Production Deployment

#### Option 1: Streamlit Cloud
1. Push code to GitHub repository
2. Connect repository to Streamlit Cloud
3. Configure environment variables
4. Deploy automatically

#### Option 2: Docker
```bash
# Build Docker image
docker build -t agritrade-pro .

# Run container
docker run -p 8501:8501 --env-file .env agritrade-pro
```

#### Option 3: Cloud Platforms
- **Heroku**: Use Procfile and requirements.txt
- **AWS**: Deploy using ECS or Lambda
- **Google Cloud**: Use Cloud Run or App Engine
- **Azure**: Deploy to Container Instances or App Service

## Performance Optimization

- Lazy loading of components
- Efficient state management
- Optimized database queries
- Caching for frequently accessed data
- Responsive design for all screen sizes

## Troubleshooting

### Common Issues

1. **Application won't start**
   - Check Python version (3.8+ required)
   - Verify all dependencies are installed
   - Ensure .env file is properly configured

2. **AI features not working**
   - Verify GEMINI_API_KEY is set correctly
   - Check internet connection
   - Ensure API key has proper permissions

3. **Database errors**
   - Check data/ directory permissions
   - Verify SQLite installation
   - Clear data/mandi_setu.db and restart

4. **UI rendering issues**
   - Clear browser cache
   - Try different browser
   - Check console for JavaScript errors

### Getting Help

- Check existing GitHub issues
- Create new issue with detailed description
- Include error messages and system information
- Provide steps to reproduce the problem

## Contributing

We welcome contributions! Please follow these guidelines:

1. **Fork the repository**
2. **Create feature branch** (`git checkout -b feature/amazing-feature`)
3. **Make changes** with proper tests and documentation
4. **Commit changes** (`git commit -m 'Add amazing feature'`)
5. **Push to branch** (`git push origin feature/amazing-feature`)
6. **Open Pull Request** with detailed description

### Code Standards
- Follow PEP 8 style guidelines
- Add type hints where appropriate
- Write comprehensive tests
- Update documentation for new features
- Ensure backward compatibility

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Built for agricultural market vendors across India
- Inspired by the Digital India initiative
- Designed to bridge the digital divide through voice-first interactions
- Supports the vision of Viksit Bharat (Developed India)

## Support

For support and questions:
- **GitHub Issues**: Create an issue for bugs or feature requests
- **Documentation**: Check this README and inline code documentation
- **Community**: Join discussions in GitHub Discussions

---

**Built for Viksit Bharat | विकसित भारत के लिए बनाया गया**