"""
Configuration management for Mandi-Setu application.
Handles API keys, database settings, and environment-specific configurations.
"""

import os
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class DatabaseConfig(BaseModel):
    """Database configuration settings."""
    
    # SQLite settings (development)
    sqlite_path: str = Field(default="data/mandi_setu.db")
    
    # DynamoDB settings (production)
    dynamodb_table_name: str = Field(default="mandi-setu-parchis")
    dynamodb_region: str = Field(default="us-east-1")
    
    # Environment mode
    use_dynamodb: bool = Field(default=False)


class AIConfig(BaseModel):
    """AI and language processing configuration."""
    
    # Gemini API settings
    gemini_api_key: Optional[str] = Field(default=None)
    gemini_model: str = Field(default="gemini-1.5-flash")
    
    # Supported languages
    supported_languages: list[str] = Field(default=[
        "hi",  # Hindi
        "ta",  # Tamil
        "te",  # Telugu
        "bn",  # Bengali
        "mr",  # Marathi
        "gu",  # Gujarati
        "en"   # English (fallback)
    ])
    
    # Language detection settings
    default_language: str = Field(default="en")
    confidence_threshold: float = Field(default=0.7)


class UIConfig(BaseModel):
    """User interface configuration."""
    
    # Theme colors (Viksit Bharat)
    primary_color: str = Field(default="#FF9933")  # Saffron
    secondary_color: str = Field(default="#138808")  # Green
    background_color: str = Field(default="#FFFFFF")  # White
    
    # Layout settings
    sidebar_width: int = Field(default=300)
    max_trade_ledger_items: int = Field(default=50)
    
    # Performance settings
    auto_refresh_interval: int = Field(default=1000)  # milliseconds


class PerformanceConfig(BaseModel):
    """Performance and timeout configuration."""
    
    # Response time limits (seconds)
    voice_feedback_timeout: float = Field(default=2.0)
    data_extraction_timeout: float = Field(default=5.0)
    ui_update_timeout: float = Field(default=1.0)
    database_operation_timeout: float = Field(default=0.5)
    
    # Retry settings
    max_retries: int = Field(default=3)
    retry_delay: float = Field(default=1.0)
    
    # Cache settings
    session_cache_size: int = Field(default=100)
    conversation_history_limit: int = Field(default=20)


class AppConfig(BaseModel):
    """Main application configuration."""
    
    # Sub-configurations
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    ai: AIConfig = Field(default_factory=AIConfig)
    ui: UIConfig = Field(default_factory=UIConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    
    # Application metadata
    app_name: str = Field(default="AgriTrade Pro")
    version: str = Field(default="1.0.0")
    debug_mode: bool = Field(default=False)
    
    # Environment detection
    environment: str = Field(default="development")
    
    @classmethod
    def load_from_env(cls) -> "AppConfig":
        """Load configuration from environment variables."""
        
        # Create base config
        config = cls()
        
        # Override with environment variables
        config.ai.gemini_api_key = os.getenv("GEMINI_API_KEY")
        config.database.use_dynamodb = os.getenv("USE_DYNAMODB", "false").lower() == "true"
        config.database.dynamodb_region = os.getenv("AWS_REGION", config.database.dynamodb_region)
        config.debug_mode = os.getenv("DEBUG", "false").lower() == "true"
        config.environment = os.getenv("ENVIRONMENT", "development")
        
        # Validate required settings
        if not config.ai.gemini_api_key and config.environment == "production":
            raise ValueError("GEMINI_API_KEY is required for production environment")
        
        return config
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return self.model_dump()
    
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment == "production"
    
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.environment == "development"


# Global configuration instance
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = AppConfig.load_from_env()
    return _config


def reload_config() -> AppConfig:
    """Reload configuration from environment."""
    global _config
    _config = AppConfig.load_from_env()
    return _config


# Export commonly used configurations
def get_database_config() -> DatabaseConfig:
    """Get database configuration."""
    return get_config().database


def get_ai_config() -> AIConfig:
    """Get AI configuration."""
    return get_config().ai


def get_ui_config() -> UIConfig:
    """Get UI configuration."""
    return get_config().ui


def get_performance_config() -> PerformanceConfig:
    """Get performance configuration."""
    return get_config().performance