"""
DynamoDB database implementation for Mandi-Setu production mode.

This module provides a DynamoDB-based implementation of the DatabaseManager
interface, suitable for production deployment with cloud scalability.
"""

import json
import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any, Union
from decimal import Decimal
import logging

try:
    import boto3
    from botocore.exceptions import ClientError, BotoCoreError
    from boto3.dynamodb.conditions import Key, Attr
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False
    boto3 = None
    ClientError = Exception
    BotoCoreError = Exception

try:
    from .base import DatabaseManager, DatabaseError, ValidationError, ConnectionError
    from ..models.core import DigitalParchi, TradeData, ParchiStatus
except ImportError:
    # Fallback for direct module loading
    import sys
    from pathlib import Path
    
    # Add database and models to path
    db_path = Path(__file__).parent
    models_path = db_path.parent / "models"
    sys.path.insert(0, str(db_path))
    sys.path.insert(0, str(models_path))
    
    try:
        from base import DatabaseManager, DatabaseError, ValidationError, ConnectionError
        from core import DigitalParchi, TradeData, ParchiStatus
    except ImportError:
        # Create minimal placeholders for testing
        class DatabaseManager: pass
        class DatabaseError(Exception): pass
        class ValidationError(Exception): pass
        class ConnectionError(Exception): pass
        class DigitalParchi: pass
        class TradeData: pass
        class ParchiStatus: pass


logger = logging.getLogger(__name__)


class DynamoDBManager(DatabaseManager):
    """
    DynamoDB implementation of the DatabaseManager interface.
    
    Provides cloud-based storage for Digital Parchi records,
    suitable for production environments with automatic scaling.
    """
    
    def __init__(
        self,
        table_name: str = "mandi-setu-parchis",
        region: str = "us-east-1",
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None
    ):
        """
        Initialize DynamoDB database manager.
        
        Args:
            table_name: Name of the DynamoDB table
            region: AWS region for DynamoDB
            aws_access_key_id: AWS access key (optional, uses default credentials if not provided)
            aws_secret_access_key: AWS secret key (optional, uses default credentials if not provided)
        """
        if not BOTO3_AVAILABLE:
            raise ImportError(
                "boto3 is required for DynamoDB support. "
                "Install it with: pip install boto3"
            )
        
        self.table_name = table_name
        self.region = region
        self._dynamodb = None
        self._table = None
        self._initialized = False
        
        # AWS credentials (optional - will use default credential chain if not provided)
        self._aws_credentials = {}
        if aws_access_key_id and aws_secret_access_key:
            self._aws_credentials = {
                'aws_access_key_id': aws_access_key_id,
                'aws_secret_access_key': aws_secret_access_key
            }
    
    async def initialize(self) -> None:
        """Initialize DynamoDB connection and ensure table exists."""
        try:
            # Create DynamoDB resource
            self._dynamodb = boto3.resource(
                'dynamodb',
                region_name=self.region,
                **self._aws_credentials
            )
            
            # Get table reference
            self._table = self._dynamodb.Table(self.table_name)
            
            # Check if table exists and is active
            await self._ensure_table_exists()
            
            self._initialized = True
            logger.info(f"DynamoDB table '{self.table_name}' initialized in region '{self.region}'")
            
        except (ClientError, BotoCoreError) as e:
            raise ConnectionError(f"Failed to initialize DynamoDB: {e}", e)
    
    async def _ensure_table_exists(self) -> None:
        """Ensure the DynamoDB table exists and is active."""
        try:
            # Check table status
            response = self._table.meta.client.describe_table(TableName=self.table_name)
            table_status = response['Table']['TableStatus']
            
            if table_status != 'ACTIVE':
                raise ConnectionError(f"DynamoDB table '{self.table_name}' is not active (status: {table_status})")
            
            logger.debug(f"DynamoDB table '{self.table_name}' is active")
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            
            if error_code == 'ResourceNotFoundException':
                raise ConnectionError(
                    f"DynamoDB table '{self.table_name}' does not exist. "
                    f"Please create the table with partition key 'id' (String) "
                    f"and sort key 'created_at' (String)"
                )
            else:
                raise ConnectionError(f"Failed to access DynamoDB table: {e}", e)
    
    def _ensure_initialized(self) -> None:
        """Ensure database is initialized."""
        if not self._initialized or not self._table:
            raise DatabaseError("Database not initialized. Call initialize() first.")
    
    def _convert_decimals(self, obj: Any) -> Any:
        """Convert Decimal objects to float for JSON serialization."""
        if isinstance(obj, dict):
            return {k: self._convert_decimals(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_decimals(v) for v in obj]
        elif isinstance(obj, Decimal):
            return float(obj)
        else:
            return obj
    
    def _prepare_for_dynamodb(self, obj: Any) -> Any:
        """Prepare object for DynamoDB by converting floats to Decimals."""
        if isinstance(obj, dict):
            return {k: self._prepare_for_dynamodb(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._prepare_for_dynamodb(v) for v in obj]
        elif isinstance(obj, float):
            return Decimal(str(obj))
        else:
            return obj
    
    def _parchi_to_item(self, parchi: DigitalParchi) -> Dict[str, Any]:
        """Convert DigitalParchi to DynamoDB item."""
        item = {
            'id': parchi.id,
            'created_at': parchi.created_at.isoformat(),
            'updated_at': parchi.updated_at.isoformat(),
            'product_name': parchi.trade_data.product_name,
            'quantity': parchi.trade_data.quantity,
            'unit': parchi.trade_data.unit,
            'unit_price': parchi.trade_data.unit_price,
            'total_amount': parchi.trade_data.total_amount,
            'mandi_cess': parchi.trade_data.mandi_cess,
            'language': parchi.trade_data.language,
            'conversation_id': parchi.trade_data.conversation_id,
            'status': parchi.status.value,
            'trade_data': parchi.trade_data.model_dump(),
            'timestamp': parchi.trade_data.timestamp.isoformat()
        }
        
        # Add optional fields
        if parchi.vendor_id:
            item['vendor_id'] = parchi.vendor_id
        
        # Convert floats to Decimals for DynamoDB
        return self._prepare_for_dynamodb(item)
    
    def _item_to_parchi(self, item: Dict[str, Any]) -> DigitalParchi:
        """Convert DynamoDB item to DigitalParchi."""
        try:
            # Convert Decimals back to floats
            item = self._convert_decimals(item)
            
            # Parse trade data
            trade_data_dict = item['trade_data']
            trade_data = TradeData(**trade_data_dict)
            
            return DigitalParchi(
                id=item['id'],
                trade_data=trade_data,
                vendor_id=item.get('vendor_id'),
                status=ParchiStatus(item['status']),
                created_at=datetime.fromisoformat(item['created_at']),
                updated_at=datetime.fromisoformat(item['updated_at'])
            )
        except (KeyError, ValueError, TypeError) as e:
            raise ValidationError(f"Failed to parse parchi data: {e}", e)
    
    async def save_parchi(self, parchi: DigitalParchi) -> str:
        """Save a Digital Parchi to DynamoDB."""
        self._ensure_initialized()
        
        try:
            # Validate parchi data
            if not parchi.id:
                raise ValidationError("Parchi ID is required")
            
            # Convert to DynamoDB item
            item = self._parchi_to_item(parchi)
            
            # Save to DynamoDB
            self._table.put_item(Item=item)
            
            logger.debug(f"Saved parchi {parchi.id} to DynamoDB")
            return parchi.id
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to save parchi to DynamoDB: {e}", e)
    
    async def get_parchi(self, parchi_id: str) -> Optional[DigitalParchi]:
        """Retrieve a Digital Parchi by ID from DynamoDB."""
        self._ensure_initialized()
        
        try:
            # Query by partition key (id)
            response = self._table.query(
                KeyConditionExpression=Key('id').eq(parchi_id),
                ScanIndexForward=False,  # Most recent first
                Limit=1
            )
            
            items = response.get('Items', [])
            if not items:
                return None
            
            return self._item_to_parchi(items[0])
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to retrieve parchi from DynamoDB: {e}", e)
    
    async def list_parchis(
        self,
        limit: int = 50,
        offset: int = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[DigitalParchi]:
        """List Digital Parchis from DynamoDB with filtering and pagination."""
        self._ensure_initialized()
        
        try:
            # Build scan parameters
            scan_kwargs = {
                'Limit': limit + offset,  # DynamoDB doesn't support offset directly
                'Select': 'ALL_ATTRIBUTES'
            }
            
            # Add date filtering if provided
            filter_expressions = []
            
            if start_date:
                filter_expressions.append(Attr('created_at').gte(start_date.isoformat()))
            
            if end_date:
                filter_expressions.append(Attr('created_at').lte(end_date.isoformat()))
            
            if filter_expressions:
                filter_expression = filter_expressions[0]
                for expr in filter_expressions[1:]:
                    filter_expression = filter_expression & expr
                scan_kwargs['FilterExpression'] = filter_expression
            
            # Scan table (Note: In production, consider using GSI for better performance)
            response = self._table.scan(**scan_kwargs)
            items = response.get('Items', [])
            
            # Sort by created_at descending (most recent first)
            items.sort(key=lambda x: x['created_at'], reverse=True)
            
            # Apply offset manually (since DynamoDB doesn't support it directly)
            items = items[offset:offset + limit]
            
            return [self._item_to_parchi(item) for item in items]
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to list parchis from DynamoDB: {e}", e)
    
    async def update_parchi(self, parchi_id: str, updates: Dict[str, Any]) -> bool:
        """Update a Digital Parchi in DynamoDB."""
        self._ensure_initialized()
        
        try:
            # First check if parchi exists
            existing_parchi = await self.get_parchi(parchi_id)
            if not existing_parchi:
                return False
            
            # Build update expression
            update_expressions = []
            expression_values = {}
            
            # Handle allowed updates
            allowed_fields = ['status', 'vendor_id']
            
            for field, value in updates.items():
                if field in allowed_fields:
                    update_expressions.append(f"{field} = :{field}")
                    if field == 'status' and isinstance(value, ParchiStatus):
                        expression_values[f":{field}"] = value.value
                    else:
                        expression_values[f":{field}"] = value
            
            # Always update the updated_at timestamp
            update_expressions.append("updated_at = :updated_at")
            expression_values[":updated_at"] = datetime.now().isoformat()
            
            if not update_expressions:
                return True  # No valid updates
            
            # Update item in DynamoDB
            self._table.update_item(
                Key={
                    'id': parchi_id,
                    'created_at': existing_parchi.created_at.isoformat()
                },
                UpdateExpression="SET " + ", ".join(update_expressions),
                ExpressionAttributeValues=expression_values
            )
            
            return True
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to update parchi in DynamoDB: {e}", e)
    
    async def delete_parchi(self, parchi_id: str) -> bool:
        """Delete a Digital Parchi from DynamoDB."""
        self._ensure_initialized()
        
        try:
            # First get the parchi to find the sort key
            existing_parchi = await self.get_parchi(parchi_id)
            if not existing_parchi:
                return False
            
            # Delete from DynamoDB
            self._table.delete_item(
                Key={
                    'id': parchi_id,
                    'created_at': existing_parchi.created_at.isoformat()
                }
            )
            
            return True
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to delete parchi from DynamoDB: {e}", e)
    
    async def count_parchis(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> int:
        """Count Digital Parchis in DynamoDB with optional date filtering."""
        self._ensure_initialized()
        
        try:
            # Build scan parameters for counting
            scan_kwargs = {
                'Select': 'COUNT'
            }
            
            # Add date filtering if provided
            filter_expressions = []
            
            if start_date:
                filter_expressions.append(Attr('created_at').gte(start_date.isoformat()))
            
            if end_date:
                filter_expressions.append(Attr('created_at').lte(end_date.isoformat()))
            
            if filter_expressions:
                filter_expression = filter_expressions[0]
                for expr in filter_expressions[1:]:
                    filter_expression = filter_expression & expr
                scan_kwargs['FilterExpression'] = filter_expression
            
            # Scan table to count items
            response = self._table.scan(**scan_kwargs)
            return response.get('Count', 0)
            
        except (ClientError, BotoCoreError) as e:
            raise DatabaseError(f"Failed to count parchis in DynamoDB: {e}", e)
    
    async def health_check(self) -> Dict[str, Any]:
        """Check DynamoDB health and connectivity."""
        try:
            if not self._initialized or not self._table:
                return {
                    'status': 'unhealthy',
                    'error': 'Database not initialized'
                }
            
            # Test basic operation
            response = self._table.meta.client.describe_table(TableName=self.table_name)
            table_info = response['Table']
            
            # Get item count (approximate)
            item_count = table_info.get('ItemCount', 0)
            
            return {
                'status': 'healthy',
                'database_type': 'dynamodb',
                'table_name': self.table_name,
                'region': self.region,
                'table_status': table_info['TableStatus'],
                'approximate_item_count': item_count,
                'table_size_bytes': table_info.get('TableSizeBytes', 0),
                'connection_active': True
            }
            
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e)
            }
    
    async def close(self) -> None:
        """Close DynamoDB connections and cleanup resources."""
        # DynamoDB connections are managed by boto3, no explicit cleanup needed
        self._dynamodb = None
        self._table = None
        self._initialized = False
        logger.info("DynamoDB connection closed")