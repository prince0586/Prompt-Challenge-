"""
Database package for Mandi-Setu.

This package provides database abstraction and implementations for storing
Digital Parchi records with support for both SQLite (development) and
DynamoDB (production) backends.
"""

from .base import (
    DatabaseManager,
    DatabaseError,
    ValidationError,
    ConnectionError,
    OperationTimeoutError
)
from .sqlite_manager import SQLiteManager
from .dynamodb_manager import DynamoDBManager
from .factory import (
    create_database_manager,
    create_sqlite_manager,
    create_dynamodb_manager,
    initialize_database,
    get_initialized_database_manager
)

__all__ = [
    # Base classes and exceptions
    'DatabaseManager',
    'DatabaseError',
    'ValidationError',
    'ConnectionError',
    'OperationTimeoutError',
    
    # Implementations
    'SQLiteManager',
    'DynamoDBManager',
    
    # Factory functions
    'create_database_manager',
    'create_sqlite_manager',
    'create_dynamodb_manager',
    'initialize_database',
    'get_initialized_database_manager'
]