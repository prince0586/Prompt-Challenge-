"""
Database factory for creating appropriate database managers.

This module provides factory functions to create the correct database
manager implementation based on configuration settings.
"""

import os
from typing import Optional
import logging

try:
    from .base import DatabaseManager
    from .sqlite_manager import SQLiteManager
    from .dynamodb_manager import DynamoDBManager
    from ..config.settings import DatabaseConfig
except ImportError:
    # Fallback for direct module loading
    import sys
    from pathlib import Path
    
    # Add paths
    db_path = Path(__file__).parent
    config_path = db_path.parent / "config"
    sys.path.insert(0, str(db_path))
    sys.path.insert(0, str(config_path))
    
    try:
        from base import DatabaseManager
        from sqlite_manager import SQLiteManager
        from dynamodb_manager import DynamoDBManager
        try:
            from settings import DatabaseConfig
        except ImportError:
            # Create a minimal config class for testing
            class DatabaseConfig:
                def __init__(self):
                    self.use_dynamodb = False
                    self.sqlite_path = "data/mandi_setu.db"
                    self.dynamodb_table_name = "mandi-setu-parchis"
                    self.dynamodb_region = "us-east-1"
    except ImportError:
        # Create minimal placeholders
        class DatabaseManager: pass
        class SQLiteManager: pass
        class DynamoDBManager: pass
        class DatabaseConfig:
            def __init__(self):
                self.use_dynamodb = False
                self.sqlite_path = "data/mandi_setu.db"
                self.dynamodb_table_name = "mandi-setu-parchis"
                self.dynamodb_region = "us-east-1"


logger = logging.getLogger(__name__)


def create_database_manager(config: Optional[DatabaseConfig] = None) -> DatabaseManager:
    """
    Create the appropriate database manager based on configuration.
    
    Args:
        config: Database configuration. If None, will load from environment.
        
    Returns:
        DatabaseManager instance (SQLite or DynamoDB)
        
    Raises:
        ValueError: If configuration is invalid
        ImportError: If required dependencies are missing
    """
    if config is None:
        from ..config.settings import get_database_config
        config = get_database_config()
    
    if config.use_dynamodb:
        logger.info("Creating DynamoDB database manager")
        return DynamoDBManager(
            table_name=config.dynamodb_table_name,
            region=config.dynamodb_region,
            aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
            aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
        )
    else:
        logger.info("Creating SQLite database manager")
        return SQLiteManager(db_path=config.sqlite_path)


def create_sqlite_manager(db_path: str = "data/mandi_setu.db") -> SQLiteManager:
    """
    Create a SQLite database manager.
    
    Args:
        db_path: Path to the SQLite database file
        
    Returns:
        SQLiteManager instance
    """
    return SQLiteManager(db_path=db_path)


def create_dynamodb_manager(
    table_name: str = "mandi-setu-parchis",
    region: str = "us-east-1",
    aws_access_key_id: Optional[str] = None,
    aws_secret_access_key: Optional[str] = None
) -> DynamoDBManager:
    """
    Create a DynamoDB database manager.
    
    Args:
        table_name: Name of the DynamoDB table
        region: AWS region
        aws_access_key_id: AWS access key (optional)
        aws_secret_access_key: AWS secret key (optional)
        
    Returns:
        DynamoDBManager instance
        
    Raises:
        ImportError: If boto3 is not available
    """
    return DynamoDBManager(
        table_name=table_name,
        region=region,
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )


async def initialize_database(manager: DatabaseManager) -> DatabaseManager:
    """
    Initialize a database manager and return it.
    
    Args:
        manager: Database manager to initialize
        
    Returns:
        Initialized database manager
        
    Raises:
        DatabaseError: If initialization fails
    """
    await manager.initialize()
    return manager


# Convenience function for common use case
async def get_initialized_database_manager(config: Optional[DatabaseConfig] = None) -> DatabaseManager:
    """
    Create and initialize the appropriate database manager.
    
    Args:
        config: Database configuration. If None, will load from environment.
        
    Returns:
        Initialized DatabaseManager instance
        
    Raises:
        DatabaseError: If initialization fails
        ValueError: If configuration is invalid
        ImportError: If required dependencies are missing
    """
    manager = create_database_manager(config)
    return await initialize_database(manager)