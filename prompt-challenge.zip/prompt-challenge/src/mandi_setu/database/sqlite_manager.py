"""
SQLite database implementation for Mandi-Setu development mode.

This module provides a SQLite-based implementation of the DatabaseManager
interface, suitable for local development and testing.
"""

import sqlite3
import json
import asyncio
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any
import logging

try:
    from .base import DatabaseManager, DatabaseError, ValidationError, ConnectionError
    from ..models.core import DigitalParchi, TradeData, ParchiStatus
except ImportError:
    # Fallback for direct module loading
    import sys
    from pathlib import Path
    
    # Add database and models to path
    db_path = Path(__file__).parent
    models_path = db_path.parent / "models"
    sys.path.insert(0, str(db_path))
    sys.path.insert(0, str(models_path))
    
    try:
        from base import DatabaseManager, DatabaseError, ValidationError, ConnectionError
        from core import DigitalParchi, TradeData, ParchiStatus
    except ImportError:
        # Create minimal placeholders for testing
        class DatabaseManager: pass
        class DatabaseError(Exception): pass
        class ValidationError(Exception): pass
        class ConnectionError(Exception): pass
        class DigitalParchi: pass
        class TradeData: pass
        class ParchiStatus: pass


logger = logging.getLogger(__name__)


class SQLiteManager(DatabaseManager):
    """
    SQLite implementation of the DatabaseManager interface.
    
    Provides local file-based storage for Digital Parchi records,
    suitable for development and testing environments.
    """
    
    def __init__(self, db_path: str = "data/mandi_setu.db"):
        """
        Initialize SQLite database manager.
        
        Args:
            db_path: Path to the SQLite database file
        """
        self.db_path = Path(db_path)
        self._connection: Optional[sqlite3.Connection] = None
        self._initialized = False
    
    async def initialize(self) -> None:
        """Initialize the SQLite database and create tables."""
        try:
            # Create data directory if it doesn't exist
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Connect to database
            self._connection = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False,
                timeout=30.0
            )
            
            # Enable foreign keys and WAL mode for better performance
            self._connection.execute("PRAGMA foreign_keys = ON")
            self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.execute("PRAGMA synchronous = NORMAL")
            
            # Create tables
            await self._create_tables()
            
            self._initialized = True
            logger.info(f"SQLite database initialized at {self.db_path}")
            
        except sqlite3.Error as e:
            raise ConnectionError(f"Failed to initialize SQLite database: {e}", e)
    
    async def _create_tables(self) -> None:
        """Create necessary database tables."""
        create_parchis_table = """
        CREATE TABLE IF NOT EXISTS parchis (
            id TEXT PRIMARY KEY,
            product_name TEXT NOT NULL,
            quantity REAL NOT NULL CHECK (quantity > 0),
            unit TEXT NOT NULL,
            unit_price REAL NOT NULL CHECK (unit_price > 0),
            total_amount REAL NOT NULL CHECK (total_amount > 0),
            mandi_cess REAL NOT NULL CHECK (mandi_cess >= 0),
            language TEXT NOT NULL,
            conversation_id TEXT,
            vendor_id TEXT,
            status TEXT NOT NULL DEFAULT 'COMPLETED',
            created_at TIMESTAMP NOT NULL,
            updated_at TIMESTAMP NOT NULL,
            trade_data_json TEXT NOT NULL
        )
        """
        
        create_indexes = [
            "CREATE INDEX IF NOT EXISTS idx_parchis_created_at ON parchis(created_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_parchis_product ON parchis(product_name)",
            "CREATE INDEX IF NOT EXISTS idx_parchis_status ON parchis(status)",
            "CREATE INDEX IF NOT EXISTS idx_parchis_vendor ON parchis(vendor_id)",
        ]
        
        try:
            self._connection.execute(create_parchis_table)
            
            for index_sql in create_indexes:
                self._connection.execute(index_sql)
            
            self._connection.commit()
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to create tables: {e}", e)
    
    def _ensure_initialized(self) -> None:
        """Ensure database is initialized."""
        if not self._initialized or not self._connection:
            raise DatabaseError("Database not initialized. Call initialize() first.")
    
    def _parchi_to_row(self, parchi: DigitalParchi) -> Dict[str, Any]:
        """Convert DigitalParchi to database row."""
        return {
            'id': parchi.id,
            'product_name': parchi.trade_data.product_name,
            'quantity': parchi.trade_data.quantity,
            'unit': parchi.trade_data.unit,
            'unit_price': parchi.trade_data.unit_price,
            'total_amount': parchi.trade_data.total_amount,
            'mandi_cess': parchi.trade_data.mandi_cess,
            'language': parchi.trade_data.language,
            'conversation_id': parchi.trade_data.conversation_id,
            'vendor_id': parchi.vendor_id,
            'status': parchi.status.value,
            'created_at': parchi.created_at.isoformat(),
            'updated_at': parchi.updated_at.isoformat(),
            'trade_data_json': parchi.trade_data.model_dump_json()
        }
    
    def _row_to_parchi(self, row: sqlite3.Row) -> DigitalParchi:
        """Convert database row to DigitalParchi."""
        try:
            # Parse trade data from JSON
            trade_data_dict = json.loads(row['trade_data_json'])
            trade_data = TradeData(**trade_data_dict)
            
            return DigitalParchi(
                id=row['id'],
                trade_data=trade_data,
                vendor_id=row['vendor_id'],
                status=ParchiStatus(row['status']),
                created_at=datetime.fromisoformat(row['created_at']),
                updated_at=datetime.fromisoformat(row['updated_at'])
            )
        except (json.JSONDecodeError, ValueError, KeyError) as e:
            raise ValidationError(f"Failed to parse parchi data: {e}", e)
    
    async def save_parchi(self, parchi: DigitalParchi) -> str:
        """Save a Digital Parchi to SQLite database."""
        self._ensure_initialized()
        
        try:
            # Validate parchi data
            if not parchi.id:
                raise ValidationError("Parchi ID is required")
            
            # Convert to database row
            row_data = self._parchi_to_row(parchi)
            
            # Insert into database
            insert_sql = """
            INSERT OR REPLACE INTO parchis (
                id, product_name, quantity, unit, unit_price, total_amount,
                mandi_cess, language, conversation_id, vendor_id, status,
                created_at, updated_at, trade_data_json
            ) VALUES (
                :id, :product_name, :quantity, :unit, :unit_price, :total_amount,
                :mandi_cess, :language, :conversation_id, :vendor_id, :status,
                :created_at, :updated_at, :trade_data_json
            )
            """
            
            self._connection.execute(insert_sql, row_data)
            self._connection.commit()
            
            logger.debug(f"Saved parchi {parchi.id} to SQLite database")
            return parchi.id
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to save parchi: {e}", e)
    
    async def get_parchi(self, parchi_id: str) -> Optional[DigitalParchi]:
        """Retrieve a Digital Parchi by ID."""
        self._ensure_initialized()
        
        try:
            self._connection.row_factory = sqlite3.Row
            cursor = self._connection.cursor()
            
            cursor.execute(
                "SELECT * FROM parchis WHERE id = ?",
                (parchi_id,)
            )
            
            row = cursor.fetchone()
            if row is None:
                return None
            
            return self._row_to_parchi(row)
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to retrieve parchi: {e}", e)
    
    async def list_parchis(
        self,
        limit: int = 50,
        offset: int = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[DigitalParchi]:
        """List Digital Parchis with filtering and pagination."""
        self._ensure_initialized()
        
        try:
            self._connection.row_factory = sqlite3.Row
            cursor = self._connection.cursor()
            
            # Build query with optional date filtering
            where_conditions = []
            params = []
            
            if start_date:
                where_conditions.append("created_at >= ?")
                params.append(start_date.isoformat())
            
            if end_date:
                where_conditions.append("created_at <= ?")
                params.append(end_date.isoformat())
            
            where_clause = ""
            if where_conditions:
                where_clause = "WHERE " + " AND ".join(where_conditions)
            
            query = f"""
            SELECT * FROM parchis
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """
            
            params.extend([limit, offset])
            cursor.execute(query, params)
            
            rows = cursor.fetchall()
            return [self._row_to_parchi(row) for row in rows]
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to list parchis: {e}", e)
    
    async def update_parchi(self, parchi_id: str, updates: Dict[str, Any]) -> bool:
        """Update a Digital Parchi with new data."""
        self._ensure_initialized()
        
        try:
            # First check if parchi exists
            existing_parchi = await self.get_parchi(parchi_id)
            if not existing_parchi:
                return False
            
            # Build update query
            set_clauses = []
            params = []
            
            # Handle allowed updates
            allowed_fields = ['status', 'vendor_id', 'updated_at']
            
            for field, value in updates.items():
                if field in allowed_fields:
                    set_clauses.append(f"{field} = ?")
                    if field == 'status' and isinstance(value, ParchiStatus):
                        params.append(value.value)
                    elif field == 'updated_at' and isinstance(value, datetime):
                        params.append(value.isoformat())
                    else:
                        params.append(value)
            
            if not set_clauses:
                return True  # No valid updates
            
            # Always update the updated_at timestamp
            if 'updated_at' not in updates:
                set_clauses.append("updated_at = ?")
                params.append(datetime.now().isoformat())
            
            params.append(parchi_id)
            
            update_sql = f"""
            UPDATE parchis
            SET {', '.join(set_clauses)}
            WHERE id = ?
            """
            
            cursor = self._connection.cursor()
            cursor.execute(update_sql, params)
            self._connection.commit()
            
            return cursor.rowcount > 0
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to update parchi: {e}", e)
    
    async def delete_parchi(self, parchi_id: str) -> bool:
        """Delete a Digital Parchi by ID."""
        self._ensure_initialized()
        
        try:
            cursor = self._connection.cursor()
            cursor.execute("DELETE FROM parchis WHERE id = ?", (parchi_id,))
            self._connection.commit()
            
            return cursor.rowcount > 0
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to delete parchi: {e}", e)
    
    async def count_parchis(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> int:
        """Count Digital Parchis with optional date filtering."""
        self._ensure_initialized()
        
        try:
            cursor = self._connection.cursor()
            
            # Build query with optional date filtering
            where_conditions = []
            params = []
            
            if start_date:
                where_conditions.append("created_at >= ?")
                params.append(start_date.isoformat())
            
            if end_date:
                where_conditions.append("created_at <= ?")
                params.append(end_date.isoformat())
            
            where_clause = ""
            if where_conditions:
                where_clause = "WHERE " + " AND ".join(where_conditions)
            
            query = f"SELECT COUNT(*) FROM parchis {where_clause}"
            
            cursor.execute(query, params)
            result = cursor.fetchone()
            
            return result[0] if result else 0
            
        except sqlite3.Error as e:
            raise DatabaseError(f"Failed to count parchis: {e}", e)
    
    async def health_check(self) -> Dict[str, Any]:
        """Check SQLite database health."""
        try:
            if not self._initialized or not self._connection:
                return {
                    'status': 'unhealthy',
                    'error': 'Database not initialized'
                }
            
            # Test basic query
            cursor = self._connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM parchis")
            count = cursor.fetchone()[0]
            
            # Get database file size
            db_size = self.db_path.stat().st_size if self.db_path.exists() else 0
            
            return {
                'status': 'healthy',
                'database_type': 'sqlite',
                'database_path': str(self.db_path),
                'total_parchis': count,
                'database_size_bytes': db_size,
                'connection_active': True
            }
            
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e)
            }
    
    async def close(self) -> None:
        """Close SQLite database connection."""
        if self._connection:
            try:
                self._connection.close()
                self._connection = None
                self._initialized = False
                logger.info("SQLite database connection closed")
            except sqlite3.Error as e:
                logger.error(f"Error closing SQLite connection: {e}")
                raise DatabaseError(f"Failed to close database connection: {e}", e)