"""
Abstract database interface for Mandi-Setu.

This module defines the abstract base class for database operations,
providing a common interface for both SQLite and DynamoDB implementations.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from datetime import datetime

try:
    from ..models.core import DigitalParchi
except ImportError:
    # Fallback for direct module loading
    import sys
    from pathlib import Path
    models_path = Path(__file__).parent.parent / "models"
    sys.path.insert(0, str(models_path))
    try:
        from core import DigitalParchi
    except ImportError:
        # If still failing, create a minimal placeholder
        from typing import Any
        class DigitalParchi:
            pass


class DatabaseManager(ABC):
    """
    Abstract base class for database operations.
    
    This interface provides a common API for storing and retrieving
    Digital Parchi records, supporting both local SQLite storage
    for development and DynamoDB for production deployment.
    """
    
    @abstractmethod
    async def initialize(self) -> None:
        """
        Initialize the database connection and create necessary tables/resources.
        
        Raises:
            DatabaseError: If initialization fails
        """
        pass
    
    @abstractmethod
    async def save_parchi(self, parchi: DigitalParchi) -> str:
        """
        Save a Digital Parchi to the database.
        
        Args:
            parchi: The Digital Parchi to save
            
        Returns:
            The ID of the saved parchi
            
        Raises:
            DatabaseError: If save operation fails
            ValidationError: If parchi data is invalid
        """
        pass
    
    @abstractmethod
    async def get_parchi(self, parchi_id: str) -> Optional[DigitalParchi]:
        """
        Retrieve a Digital Parchi by ID.
        
        Args:
            parchi_id: Unique identifier of the parchi
            
        Returns:
            The Digital Parchi if found, None otherwise
            
        Raises:
            DatabaseError: If retrieval operation fails
        """
        pass
    
    @abstractmethod
    async def list_parchis(
        self, 
        limit: int = 50, 
        offset: int = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[DigitalParchi]:
        """
        List Digital Parchis with optional filtering and pagination.
        
        Args:
            limit: Maximum number of parchis to return (default: 50)
            offset: Number of parchis to skip (default: 0)
            start_date: Filter parchis created after this date
            end_date: Filter parchis created before this date
            
        Returns:
            List of Digital Parchis matching the criteria
            
        Raises:
            DatabaseError: If list operation fails
        """
        pass
    
    @abstractmethod
    async def update_parchi(self, parchi_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a Digital Parchi with new data.
        
        Args:
            parchi_id: Unique identifier of the parchi
            updates: Dictionary of fields to update
            
        Returns:
            True if update was successful, False if parchi not found
            
        Raises:
            DatabaseError: If update operation fails
            ValidationError: If update data is invalid
        """
        pass
    
    @abstractmethod
    async def delete_parchi(self, parchi_id: str) -> bool:
        """
        Delete a Digital Parchi by ID.
        
        Args:
            parchi_id: Unique identifier of the parchi
            
        Returns:
            True if deletion was successful, False if parchi not found
            
        Raises:
            DatabaseError: If delete operation fails
        """
        pass
    
    @abstractmethod
    async def count_parchis(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> int:
        """
        Count Digital Parchis with optional date filtering.
        
        Args:
            start_date: Count parchis created after this date
            end_date: Count parchis created before this date
            
        Returns:
            Number of parchis matching the criteria
            
        Raises:
            DatabaseError: If count operation fails
        """
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict[str, Any]:
        """
        Check database health and connectivity.
        
        Returns:
            Dictionary containing health status information
            
        Raises:
            DatabaseError: If health check fails
        """
        pass
    
    @abstractmethod
    async def close(self) -> None:
        """
        Close database connections and cleanup resources.
        
        Raises:
            DatabaseError: If cleanup fails
        """
        pass


class DatabaseError(Exception):
    """Base exception for database operations."""
    
    def __init__(self, message: str, original_error: Optional[Exception] = None):
        super().__init__(message)
        self.original_error = original_error


class ValidationError(DatabaseError):
    """Exception raised for data validation errors."""
    pass


class ConnectionError(DatabaseError):
    """Exception raised for database connection errors."""
    pass


class OperationTimeoutError(DatabaseError):
    """Exception raised when database operations timeout."""
    pass