"""
Language Manager for Mandi-Setu Application

Handles multilingual content and language switching functionality.
"""

import streamlit as st
from typing import Dict, Any
from enum import Enum

class Language(Enum):
    """Supported languages."""
    HINDI = "hi"
    ENGLISH = "en"
    TAMIL = "ta"
    TELUGU = "te"
    BENGALI = "bn"
    MARATHI = "mr"
    GUJARATI = "gu"

class LanguageManager:
    """Manages language content and switching."""
    
    def __init__(self):
        self.translations = self._load_translations()
    
    def _load_translations(self) -> Dict[str, Dict[str, str]]:
        """Load all translations."""
        return {
            "app_title": {
                "hi": "🌾 एग्रीट्रेड प्रो",
                "en": "🌾 AgriTrade Pro",
                "ta": "🌾 அக்ரிட்ரேட் ப்ரோ",
                "te": "🌾 అగ్రిట్రేడ్ ప్రో",
                "bn": "🌾 এগ্রিট্রেড প্রো",
                "mr": "🌾 अॅग्रीट्रेड प्रो",
                "gu": "🌾 એગ્રિટ્રેડ પ્રો"
            },
            "app_subtitle": {
                "hi": "आपका बहुभाषी व्यापार सहायक",
                "en": "Your Multilingual Trade Assistant",
                "ta": "உங்கள் பன்மொழி வர்த்தக உதவியாளர்",
                "te": "మీ బహుభాషా వాణిజ్య సహాయకుడు",
                "bn": "আপনার বহুভাষিক বাণিজ্য সহায়ক",
                "mr": "तुमचा बहुभाषिक व्यापार सहायक",
                "gu": "તમારા બહુભાષી વેપાર સહાયક"
            },
            "trade_negotiation": {
                "hi": "🎤 व्यापार वार्तालाप",
                "en": "🎤 Trade Negotiation",
                "ta": "🎤 வர்த்தக பேச்சுவார்த்தை",
                "te": "🎤 వాణిజ్య చర్చలు",
                "bn": "🎤 বাণিজ্য আলোচনা",
                "mr": "🎤 व्यापार चर्चा",
                "gu": "🎤 વેપાર વાટાઘાટો"
            },
            "start_negotiation": {
                "hi": "🎯 वार्तालाप शुरू करें",
                "en": "🎯 Start Negotiation",
                "ta": "🎯 பேச்சுவார்த்தையைத் தொடங்கவும்",
                "te": "🎯 చర్చలు ప్రారంభించండి",
                "bn": "🎯 আলোচনা শুরু করুন",
                "mr": "🎯 चर्चा सुरू करा",
                "gu": "🎯 વાટાઘાટો શરૂ કરો"
            },
            "start_recording": {
                "hi": "🎤 रिकॉर्डिंग शुरू करें",
                "en": "🎤 Start Recording",
                "ta": "🎤 பதிவு செய்யத் தொடங்கவும்",
                "te": "🎤 రికార్డింగ్ ప్రారంభించండి",
                "bn": "🎤 রেকর্ডিং শুরু করুন",
                "mr": "🎤 रेकॉर्डिंग सुरू करा",
                "gu": "🎤 રેકોર્ડિંગ શરૂ કરો"
            },
            "stop_recording": {
                "hi": "⏹️ रिकॉर्डिंग रोकें",
                "en": "⏹️ Stop Recording",
                "ta": "⏹️ பதிவை நிறுத்தவும்",
                "te": "⏹️ రికార్డింగ్ ఆపండి",
                "bn": "⏹️ রেকর্ডিং বন্ধ করুন",
                "mr": "⏹️ रेकॉर्डिंग थांबवा",
                "gu": "⏹️ રેકોર્ડિંગ બંધ કરો"
            },
            "end_negotiation": {
                "hi": "⏹️ वार्तालाप समाप्त करें",
                "en": "⏹️ End Negotiation",
                "ta": "⏹️ பேச்சுவார்த்தையை முடிக்கவும்",
                "te": "⏹️ చర్చలు ముగించండి",
                "bn": "⏹️ আলোচনা শেষ করুন",
                "mr": "⏹️ चर्चा संपवा",
                "gu": "⏹️ વાટાઘાટો સમાપ્ત કરો"
            },
            "trade_ledger": {
                "hi": "📊 व्यापार खाता",
                "en": "📊 Trade Ledger",
                "ta": "📊 வர்த्தக பதிவேடு",
                "te": "📊 వాణిజ్య లెడ్జర్",
                "bn": "📊 বাণিজ্য খাতা",
                "mr": "📊 व्यापार खाते",
                "gu": "📊 વેપાર ખાતું"
            },
            "no_trade_records": {
                "hi": "कोई व्यापार रिकॉर्ड नहीं मिला",
                "en": "No trade records found",
                "ta": "வர்த்தக பதிவுகள் எதுவும் கிடைக்கவில்லை",
                "te": "వాణిజ్య రికార్డులు కనుగొనబడలేదు",
                "bn": "কোনো বাণিজ্য রেকর্ড পাওয়া যায়নি",
                "mr": "कोणतेही व्यापार रेकॉर्ड सापडले नाहीत",
                "gu": "કોઈ વેપાર રેકોર્ડ મળ્યા નથી"
            },
            "add_sample_data": {
                "hi": "➕ नमूना डेटा जोड़ें",
                "en": "➕ Add Sample Data",
                "ta": "➕ மாதிரி தரவைச் சேர்க்கவும்",
                "te": "➕ నమూనా డేటాను జోడించండి",
                "bn": "➕ নমুনা ডেটা যোগ করুন",
                "mr": "➕ नमुना डेटा जोडा",
                "gu": "➕ નમૂનો ડેટા ઉમેરો"
            },
            "negotiation_active": {
                "hi": "🔴 वार्तालाप सक्रिय",
                "en": "🔴 Negotiation Active",
                "ta": "🔴 பேச்சுவார்த்தை செயலில்",
                "te": "🔴 చర్చలు చురుకుగా ఉన్నాయి",
                "bn": "🔴 আলোচনা সক্রিয়",
                "mr": "🔴 चर्चा सक्रिय",
                "gu": "🔴 વાટાઘાટો સક્રિય"
            },
            "recording_in_progress": {
                "hi": "🎤 रिकॉर्डिंग चल रही है...",
                "en": "🎤 Recording in progress...",
                "ta": "🎤 பதிவு நடந்து கொண்டிருக்கிறது...",
                "te": "🎤 రికార్డింగ్ కొనసాగుతోంది...",
                "bn": "🎤 রেকর্ডিং চলছে...",
                "mr": "🎤 रेकॉर्डिंग सुरू आहे...",
                "gu": "🎤 રેકોર્ડિંગ ચાલુ છે..."
            },
            "processing": {
                "hi": "⚙️ प्रसंस्करण हो रहा है...",
                "en": "⚙️ Processing...",
                "ta": "⚙️ செயலாக்கம்...",
                "te": "⚙️ ప్రాసెసింగ్...",
                "bn": "⚙️ প্রক্রিয়াকরণ...",
                "mr": "⚙️ प्रक्रिया...",
                "gu": "⚙️ પ્રક્રિયા..."
            },
            "conversation_history": {
                "hi": "📝 वार्तालाप इतिहास",
                "en": "📝 Conversation History",
                "ta": "📝 உரையாடல் வரலாறு",
                "te": "📝 సంభాషణ చరిత్ర",
                "bn": "📝 কথোপকথনের ইতিহাস",
                "mr": "📝 संभाषण इतिहास",
                "gu": "📝 વાર્તાલાપ ઇતિહાસ"
            },
            "language": {
                "hi": "भाषा",
                "en": "Language",
                "ta": "மொழி",
                "te": "భాష",
                "bn": "ভাষা",
                "mr": "भाषा",
                "gu": "ભાષા"
            },
            "select_language": {
                "hi": "भाषा चुनें",
                "en": "Select Language",
                "ta": "மொழியைத் தேர்ந்தெடுக்கவும்",
                "te": "భాషను ఎంచుకోండి",
                "bn": "ভাষা নির্বাচন করুন",
                "mr": "भाषा निवडा",
                "gu": "ભાષા પસંદ કરો"
            },
            "built_for_viksit_bharat": {
                "hi": "🇮🇳 विकसित भारत के लिए बनाया गया 🇮🇳",
                "en": "🇮🇳 Built for Viksit Bharat 🇮🇳",
                "ta": "🇮🇳 விக்சித் பாரத்திற்காக உருவாக்கப்பட்டது 🇮🇳",
                "te": "🇮🇳 విక్సిత్ భారత్ కోసం నిర్మించబడింది 🇮🇳",
                "bn": "🇮🇳 বিকশিত ভারতের জন্য তৈরি 🇮🇳",
                "mr": "🇮🇳 विकसित भारतासाठी तयार केले 🇮🇳",
                "gu": "🇮🇳 વિકસિત ભારત માટે બનાવેલ 🇮🇳"
            }
        }
    
    def get_language_options(self) -> Dict[str, str]:
        """Get language options for the selectbox."""
        return {
            "हिंदी (Hindi)": "hi",
            "English": "en",
            "தமிழ் (Tamil)": "ta",
            "తెలుగు (Telugu)": "te",
            "বাংলা (Bengali)": "bn",
            "मराठी (Marathi)": "mr",
            "ગુજરાતી (Gujarati)": "gu"
        }
    
    def get_text(self, key: str, language: str = None) -> str:
        """Get translated text for a key."""
        if language is None:
            language = st.session_state.get('current_language', 'en')
        
        if key in self.translations and language in self.translations[key]:
            return self.translations[key][language]
        
        # Fallback to English, then Hindi
        if key in self.translations:
            if 'en' in self.translations[key]:
                return self.translations[key]['en']
            elif 'hi' in self.translations[key]:
                return self.translations[key]['hi']
        
        return key  # Return key if no translation found
    
    def render_language_selector(self):
        """Render the language selector in the sidebar."""
        st.sidebar.markdown("---")
        
        # Language selector
        language_options = self.get_language_options()
        current_lang = st.session_state.get('current_language', 'en')
        
        # Find current language display name
        current_display = None
        for display, code in language_options.items():
            if code == current_lang:
                current_display = display
                break
        
        if current_display is None:
            current_display = list(language_options.keys())[0]
        
        selected_display = st.sidebar.selectbox(
            "🌐 " + self.get_text("select_language"),
            options=list(language_options.keys()),
            index=list(language_options.keys()).index(current_display),
            key="language_selector"
        )
        
        # Update session state if language changed
        selected_code = language_options[selected_display]
        if selected_code != st.session_state.get('current_language'):
            st.session_state.current_language = selected_code
            st.rerun()

# Global instance
language_manager = LanguageManager()