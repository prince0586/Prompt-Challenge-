"""
Theme Manager for Mandi-Setu Application

Implements the 'Viksit Bharat' theme with Indian tricolor elements,
ensuring proper contrast, accessibility, and responsive design.
"""

import streamlit as st
from typing import Dict, Any


def get_viksit_bharat_css() -> str:
    """Get the custom CSS for Viksit Bharat theme with professional MNC-level styling."""
    
    return """
    <style>
    /* Import Professional Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700;800&family=Poppins:wght@300;400;500;600;700;800&display=swap');
    
    /* Professional MNC-Grade Color System */
    :root {
        /* Primary Brand Colors */
        --primary-50: #FFF7ED;
        --primary-100: #FFEDD5;
        --primary-200: #FED7AA;
        --primary-300: #FDBA74;
        --primary-400: #FB923C;
        --primary-500: #F97316;
        --primary-600: #EA580C;
        --primary-700: #C2410C;
        --primary-800: #9A3412;
        --primary-900: #7C2D12;
        
        /* Secondary Brand Colors */
        --secondary-50: #ECFDF5;
        --secondary-100: #D1FAE5;
        --secondary-200: #A7F3D0;
        --secondary-300: #6EE7B7;
        --secondary-400: #34D399;
        --secondary-500: #10B981;
        --secondary-600: #059669;
        --secondary-700: #047857;
        --secondary-800: #065F46;
        --secondary-900: #064E3B;
        
        /* Neutral Colors */
        --gray-50: #F9FAFB;
        --gray-100: #F3F4F6;
        --gray-200: #E5E7EB;
        --gray-300: #D1D5DB;
        --gray-400: #9CA3AF;
        --gray-500: #6B7280;
        --gray-600: #4B5563;
        --gray-700: #374151;
        --gray-800: #1F2937;
        --gray-900: #111827;
        
        /* Accent Colors */
        --blue-500: #3B82F6;
        --blue-600: #2563EB;
        --indigo-500: #6366F1;
        --purple-500: #8B5CF6;
        --pink-500: #EC4899;
        --rose-500: #F43F5E;
        --emerald-500: #10B981;
        --teal-500: #14B8A6;
        --cyan-500: #06B6D4;
        --sky-500: #0EA5E9;
        
        /* Professional Gradients */
        --gradient-primary: linear-gradient(135deg, var(--primary-500) 0%, var(--primary-600) 50%, var(--primary-700) 100%);
        --gradient-secondary: linear-gradient(135deg, var(--secondary-500) 0%, var(--secondary-600) 50%, var(--secondary-700) 100%);
        --gradient-hero: linear-gradient(135deg, var(--primary-600) 0%, var(--secondary-600) 100%);
        --gradient-card: linear-gradient(145deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.7) 100%);
        --gradient-glass: linear-gradient(145deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%);
        
        /* Background System */
        --bg-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --bg-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        --bg-tertiary: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --bg-enterprise: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        
        /* Shadow System */
        --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
        --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        --shadow-glow: 0 0 20px rgba(249, 115, 22, 0.3);
        
        /* Animation Variables */
        --transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
        --transition-normal: 300ms cubic-bezier(0.4, 0, 0.2, 1);
        --transition-slow: 500ms cubic-bezier(0.4, 0, 0.2, 1);
        --bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
        
        /* Typography Scale */
        --text-xs: 0.75rem;
        --text-sm: 0.875rem;
        --text-base: 1rem;
        --text-lg: 1.125rem;
        --text-xl: 1.25rem;
        --text-2xl: 1.5rem;
        --text-3xl: 1.875rem;
        --text-4xl: 2.25rem;
        --text-5xl: 3rem;
        --text-6xl: 3.75rem;
        
        /* Spacing Scale */
        --space-1: 0.25rem;
        --space-2: 0.5rem;
        --space-3: 0.75rem;
        --space-4: 1rem;
        --space-5: 1.25rem;
        --space-6: 1.5rem;
        --space-8: 2rem;
        --space-10: 2.5rem;
        --space-12: 3rem;
        --space-16: 4rem;
        --space-20: 5rem;
        --space-24: 6rem;
        
        /* Border Radius Scale */
        --radius-sm: 0.25rem;
        --radius-md: 0.375rem;
        --radius-lg: 0.5rem;
        --radius-xl: 0.75rem;
        --radius-2xl: 1rem;
        --radius-3xl: 1.5rem;
        --radius-full: 9999px;
    }
    
    /* Global Reset & Base Styles */
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    
    html {
        scroll-behavior: smooth;
        font-size: 16px;
    }
    
    body {
        font-family: 'Inter', 'Noto Sans Devanagari', -apple-system, BlinkMacSystemFont, sans-serif;
        line-height: 1.6;
        color: var(--gray-800);
        background: var(--bg-enterprise);
        overflow-x: hidden;
    }
    
    /* Streamlit App Container */
    .stApp {
        background: var(--bg-enterprise);
        min-height: 100vh;
        position: relative;
    }
    
    .stApp::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: 
            radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%);
        pointer-events: none;
        z-index: -1;
    }
    
    /* Main Container */
    .main .block-container {
        padding: var(--space-6) var(--space-4);
        max-width: 1400px;
        margin: 0 auto;
        position: relative;
        z-index: 1;
    }
    
    /* Hide Streamlit Branding */
    #MainMenu, footer, header {
        visibility: hidden !important;
        height: 0 !important;
    }
    
    /* Professional Header */
    .header-container {
        background: var(--gradient-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 24px;
        padding: var(--space-12) var(--space-8);
        margin-bottom: var(--space-8);
        text-align: center;
        position: relative;
        overflow: hidden;
        box-shadow: var(--shadow-2xl);
        animation: slideInDown var(--transition-slow) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .header-container::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        animation: rotate 20s linear infinite;
        pointer-events: none;
    }
    
    .header-container::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
        animation: shimmer 3s ease-in-out infinite;
        pointer-events: none;
    }
    
    /* Hero Stats */
    .hero-stats {
        display: flex;
        justify-content: center;
        gap: var(--space-8);
        margin-bottom: var(--space-6);
        flex-wrap: wrap;
    }
    
    .stat-item {
        text-align: center;
        padding: var(--space-4);
        background: rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        min-width: 120px;
        transition: all var(--transition-normal);
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .stat-item:hover {
        transform: translateY(-5px) scale(1.05);
        box-shadow: var(--shadow-xl);
        background: rgba(255, 255, 255, 0.2);
    }
    
    .stat-number {
        font-size: var(--text-2xl);
        font-weight: 800;
        color: var(--primary-500);
        text-shadow: 0 0 10px rgba(249, 115, 22, 0.3);
    }
    
    .stat-label {
        font-size: var(--text-sm);
        color: rgba(255, 255, 255, 0.8);
        font-weight: 500;
        margin-top: var(--space-1);
    }
    
    /* Feature Badges */
    .feature-badges {
        display: flex;
        justify-content: center;
        gap: var(--space-3);
        margin-top: var(--space-6);
        flex-wrap: wrap;
    }
    
    .badge {
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-2) var(--space-4);
        border-radius: 50px;
        font-size: var(--text-sm);
        font-weight: 600;
        box-shadow: var(--shadow-md);
        animation: fadeInUp var(--transition-normal) var(--bounce);
        transition: all var(--transition-normal);
    }
    
    .badge:hover {
        transform: translateY(-2px) scale(1.05);
        box-shadow: var(--shadow-lg), 0 0 20px rgba(249, 115, 22, 0.4);
    }
    
    /* AI Status Panel */
    .ai-status-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-6) 0;
        display: flex;
        align-items: center;
        gap: var(--space-4);
        box-shadow: var(--shadow-xl);
        animation: slideInLeft var(--transition-normal) var(--bounce);
        position: relative;
        overflow: hidden;
    }
    
    .ai-status-panel::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.1), transparent);
        transition: left var(--transition-slow);
    }
    
    .ai-status-panel:hover::before {
        left: 100%;
    }
    
    .ai-avatar {
        font-size: var(--text-4xl);
        animation: pulse 2s ease-in-out infinite;
        filter: drop-shadow(0 0 10px rgba(16, 185, 129, 0.5));
    }
    
    .ai-info {
        flex: 1;
    }
    
    .ai-name {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-1);
    }
    
    .ai-status {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    .ai-capabilities {
        display: flex;
        flex-direction: column;
        gap: var(--space-2);
    }
    
    .capability {
        background: var(--gradient-secondary);
        color: white;
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-xs);
        font-weight: 600;
        text-align: center;
        box-shadow: var(--shadow-sm);
        animation: slideInRight var(--transition-normal) var(--bounce);
    }
    
    /* Market Insights Panel */
    .market-insights-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-6) 0;
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .market-insights-panel h3 {
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        font-size: var(--text-xl);
        font-weight: 700;
    }
    
    .insights-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .insight-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-3);
        box-shadow: var(--shadow-md);
        transition: all var(--transition-normal);
        border-left: 4px solid var(--primary-500);
    }
    
    .insight-card:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-xl);
    }
    
    .insight-card.trending-up {
        border-left-color: var(--secondary-500);
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .insight-card.trending-down {
        border-left-color: var(--rose-500);
        background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .insight-card.stable {
        border-left-color: var(--blue-500);
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .insight-icon {
        font-size: var(--text-2xl);
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
    }
    
    .insight-title {
        font-weight: 600;
        color: var(--gray-800);
        font-size: var(--text-sm);
    }
    
    .insight-price {
        font-weight: 700;
        color: var(--primary-600);
        font-size: var(--text-lg);
    }
    
    .insight-trend {
        font-weight: 600;
        font-size: var(--text-sm);
    }
    
    .market-alert {
        background: linear-gradient(135deg, var(--primary-500), var(--secondary-500));
        color: white;
        padding: var(--space-4);
        border-radius: 12px;
        display: flex;
        align-items: center;
        gap: var(--space-3);
        font-weight: 600;
        box-shadow: var(--shadow-lg);
        animation: pulse 3s ease-in-out infinite;
    }
    
    .alert-icon {
        font-size: var(--text-lg);
        animation: bounce 2s ease-in-out infinite;
    }
    
    @keyframes bounce {
        0%, 20%, 50%, 80%, 100% {
            transform: translateY(0);
        }
        40% {
            transform: translateY(-10px);
        }
        60% {
            transform: translateY(-5px);
        }
    }
    
    @keyframes shimmer {
        0% {
            background-position: -200% 0;
        }
        100% {
            background-position: 200% 0;
        }
    }
    
    @keyframes borderGlow {
        0%, 100% {
            opacity: 0.3;
        }
        50% {
            opacity: 0.8;
        }
    }
    
    @keyframes float {
        0%, 100% {
            transform: translateY(0px);
        }
        50% {
            transform: translateY(-10px);
        }
    }
    
    .app-title {
        font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        font-size: clamp(var(--text-3xl), 5vw, var(--text-6xl));
        font-weight: 800;
        background: var(--gradient-hero);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: var(--space-4);
        position: relative;
        z-index: 2;
        text-shadow: 0 0 30px rgba(249, 115, 22, 0.5);
        animation: textGlow 3s ease-in-out infinite alternate, float 6s ease-in-out infinite;
        transform-style: preserve-3d;
        perspective: 1000px;
    }
    
    .app-title::before {
        content: attr(data-text);
        position: absolute;
        top: 0;
        left: 0;
        z-index: -1;
        background: linear-gradient(45deg, rgba(249, 115, 22, 0.3), rgba(16, 185, 129, 0.3));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        transform: translateZ(-10px) scale(1.1);
        filter: blur(2px);
        opacity: 0.7;
    }
    
    .app-subtitle {
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        font-size: var(--text-xl);
        font-weight: 500;
        color: rgba(255, 255, 255, 0.9);
        position: relative;
        z-index: 2;
        opacity: 0;
        animation: fadeInUp var(--transition-slow) var(--bounce) 0.3s forwards;
    }
    
    /* Professional Card System */
    .main-card {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-8);
        margin: var(--space-6) 0;
        box-shadow: var(--shadow-xl);
        position: relative;
        overflow: hidden;
        transition: all var(--transition-normal);
        animation: slideInUp var(--transition-slow) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .main-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-slow);
    }
    
    .main-card::after {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: linear-gradient(45deg, var(--primary-500), var(--secondary-500), var(--blue-500), var(--purple-500));
        border-radius: 22px;
        z-index: -1;
        opacity: 0;
        transition: opacity var(--transition-normal);
        animation: borderGlow 4s ease-in-out infinite;
    }
    
    .main-card:hover::before {
        left: 100%;
    }
    
    .main-card:hover::after {
        opacity: 0.6;
    }
    
    .main-card:hover {
        transform: translateY(-8px) rotateX(5deg) rotateY(5deg);
        box-shadow: var(--shadow-2xl), var(--shadow-glow), 0 0 40px rgba(249, 115, 22, 0.3);
    }
    
    /* Enterprise Button System */
    .stButton > button {
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        font-weight: 600;
        border: none;
        border-radius: 16px;
        padding: var(--space-4) var(--space-8);
        font-size: var(--text-base);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        transition: all var(--transition-normal);
        text-transform: none;
        letter-spacing: 0.025em;
        min-height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-lg);
    }
    
    .stButton > button::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left var(--transition-normal);
    }
    
    .stButton > button:hover::before {
        left: 100%;
    }
    
    /* Primary Button */
    .stButton > button[kind="primary"] {
        background: var(--gradient-primary);
        color: white;
        font-weight: 700;
        font-size: var(--text-lg);
        min-height: 64px;
        box-shadow: var(--shadow-xl), 0 0 20px rgba(249, 115, 22, 0.4);
        position: relative;
        overflow: hidden;
    }
    
    .stButton > button[kind="primary"]::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%);
        transition: all var(--transition-normal);
        transform: translate(-50%, -50%);
        border-radius: 50%;
    }
    
    .stButton > button[kind="primary"]:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-2xl), 0 0 30px rgba(249, 115, 22, 0.6), 0 0 60px rgba(249, 115, 22, 0.3);
    }
    
    .stButton > button[kind="primary"]:hover::after {
        width: 300px;
        height: 300px;
    }
    
    .stButton > button[kind="primary"]:active {
        transform: translateY(-1px) scale(1.01);
    }
    
    /* Secondary Button */
    .stButton > button[kind="secondary"] {
        background: var(--gradient-secondary);
        color: white;
        font-weight: 600;
        min-height: 56px;
        box-shadow: var(--shadow-lg), 0 0 15px rgba(16, 185, 129, 0.3);
    }
    
    .stButton > button[kind="secondary"]:hover {
        transform: translateY(-2px) scale(1.01);
        box-shadow: var(--shadow-xl), 0 0 25px rgba(16, 185, 129, 0.5);
    }
    
    /* Tertiary Button */
    .stButton > button[kind="tertiary"] {
        background: linear-gradient(135deg, var(--blue-500) 0%, var(--indigo-500) 100%);
        color: white;
        font-weight: 500;
        min-height: 48px;
        box-shadow: var(--shadow-md), 0 0 10px rgba(59, 130, 246, 0.3);
    }
    
    .stButton > button[kind="tertiary"]:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg), 0 0 20px rgba(59, 130, 246, 0.4);
    }
    
    /* Professional Status Indicators */
    .status-indicator {
        display: inline-flex;
        align-items: center;
        padding: var(--space-3) var(--space-6);
        border-radius: 50px;
        font-weight: 600;
        font-size: var(--text-sm);
        margin: var(--space-4) 0;
        position: relative;
        overflow: hidden;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        animation: slideInRight var(--transition-normal) var(--bounce);
    }
    
    .status-active {
        background: linear-gradient(135deg, var(--secondary-500), var(--emerald-500));
        color: white;
        box-shadow: var(--shadow-lg), 0 0 20px rgba(16, 185, 129, 0.4);
        animation: pulse 2s ease-in-out infinite;
    }
    
    .status-recording {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
        box-shadow: var(--shadow-lg), 0 0 20px rgba(244, 63, 94, 0.4);
        animation: pulse 1.5s ease-in-out infinite;
    }
    
    .status-processing {
        background: linear-gradient(135deg, var(--blue-500), var(--cyan-500));
        color: white;
        box-shadow: var(--shadow-lg), 0 0 20px rgba(59, 130, 246, 0.4);
        animation: processing 2s ease-in-out infinite;
    }
    
    /* Enhanced Message Styling */
    .stSuccess, .stWarning, .stInfo, .stError {
        border-radius: 16px;
        padding: var(--space-4) var(--space-6);
        margin: var(--space-4) 0;
        border: none;
        backdrop-filter: blur(10px);
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        font-weight: 500;
        box-shadow: var(--shadow-md);
        animation: slideInLeft var(--transition-normal) var(--bounce);
    }
    
    .stSuccess {
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.1));
        border-left: 4px solid var(--secondary-500);
        color: var(--secondary-700);
    }
    
    .stWarning {
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(251, 191, 36, 0.1));
        border-left: 4px solid var(--primary-500);
        color: var(--primary-700);
    }
    
    .stInfo {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(147, 197, 253, 0.1));
        border-left: 4px solid var(--blue-500);
        color: var(--blue-700);
    }
    
    /* Professional Expander */
    .streamlit-expanderHeader {
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        font-weight: 600;
        background: var(--gradient-card);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: var(--space-4) var(--space-6);
        transition: all var(--transition-normal);
        box-shadow: var(--shadow-sm);
    }
    
    .streamlit-expanderHeader:hover {
        background: rgba(255, 255, 255, 0.9);
        box-shadow: var(--shadow-md);
        transform: translateY(-1px);
    }
    
    .streamlit-expanderContent {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 0 0 12px 12px;
        padding: var(--space-6);
        box-shadow: var(--shadow-lg);
    }
    
    /* Advanced 3D Effects and Animations */
    @keyframes rotate {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }
    
    @keyframes slideInDown {
        from {
            opacity: 0;
            transform: translate3d(0, -100%, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translate3d(0, 100%, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translate3d(-100%, 0, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translate3d(100%, 0, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translate3d(0, 30px, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translate3d(0, -30px, 0);
        }
        to {
            opacity: 1;
            transform: translate3d(0, 0, 0);
        }
    }
    
    @keyframes scaleIn {
        from {
            opacity: 0;
            transform: scale3d(0.3, 0.3, 0.3);
        }
        50% {
            opacity: 1;
        }
        to {
            opacity: 1;
            transform: scale3d(1, 1, 1);
        }
    }
    
    @keyframes pulse {
        0% {
            transform: scale3d(1, 1, 1);
        }
        50% {
            transform: scale3d(1.05, 1.05, 1.05);
        }
        100% {
            transform: scale3d(1, 1, 1);
        }
    }
    
    @keyframes textGlow {
        from {
            text-shadow: 0 0 20px rgba(249, 115, 22, 0.5), 0 0 30px rgba(16, 185, 129, 0.3);
        }
        to {
            text-shadow: 0 0 30px rgba(249, 115, 22, 0.8), 0 0 40px rgba(16, 185, 129, 0.5);
        }
    }
    
    @keyframes processing {
        0% {
            transform: translateX(-100%);
        }
        100% {
            transform: translateX(100%);
        }
    }
    
    /* Loading Spinner */
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
    
    /* Section Headers with Advanced Styling */
    .section-header {
        font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        font-size: var(--text-2xl);
        font-weight: 700;
        color: var(--gray-800);
        margin: var(--space-8) 0 var(--space-6) 0;
        text-align: center;
        position: relative;
        padding: var(--space-4) 0;
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow: var(--shadow-lg);
        animation: slideInDown var(--transition-normal) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .section-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.1) 50%, transparent 70%);
        animation: shimmer 3s ease-in-out infinite;
        pointer-events: none;
        border-radius: 16px;
    }
    
    .section-header:hover {
        transform: translateY(-3px) rotateX(5deg);
        box-shadow: var(--shadow-xl), 0 0 30px rgba(249, 115, 22, 0.3);
    }
    
    /* Advanced Trade Cards */
    .trade-card-enhanced {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-4) 0;
        box-shadow: var(--shadow-xl);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-normal) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .trade-card-enhanced::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-slow);
    }
    
    .trade-card-enhanced::after {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: linear-gradient(45deg, var(--primary-500), var(--secondary-500));
        border-radius: 22px;
        z-index: -1;
        opacity: 0;
        transition: opacity var(--transition-normal);
    }
    
    .trade-card-enhanced:hover::before {
        left: 100%;
    }
    
    .trade-card-enhanced:hover::after {
        opacity: 0.3;
    }
    
    .trade-card-enhanced:hover {
        transform: translateY(-8px) rotateX(5deg) rotateY(5deg) scale(1.02);
        box-shadow: var(--shadow-2xl), 0 0 40px rgba(249, 115, 22, 0.4);
    }
    
    .trade-card-enhanced.profitable {
        border-left: 6px solid var(--secondary-500);
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-card-enhanced.moderate {
        border-left: 6px solid var(--primary-500);
        background: linear-gradient(135deg, rgba(249, 115, 22, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-card-enhanced.loss {
        border-left: 6px solid var(--rose-500);
        background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .trade-product {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
    }
    
    .trade-status {
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-xs);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .trade-status.profitable {
        background: var(--gradient-secondary);
        color: white;
    }
    
    .trade-status.moderate {
        background: var(--gradient-primary);
        color: white;
    }
    
    .trade-status.loss {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .trade-metrics {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .metric {
        text-align: center;
        padding: var(--space-3);
        background: rgba(255, 255, 255, 0.5);
        border-radius: 12px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        transition: all var(--transition-normal);
    }
    
    .metric:hover {
        transform: translateY(-2px) scale(1.05);
        box-shadow: var(--shadow-md);
    }
    
    .metric-value {
        display: block;
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--primary-600);
    }
    
    .metric-unit {
        font-size: var(--text-xs);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    .trade-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: var(--space-3);
        border-top: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    .trade-time {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    .profit-indicator {
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-sm);
        font-weight: 700;
        background: var(--gradient-secondary);
        color: white;
        box-shadow: var(--shadow-sm);
    }
    
    /* Empty State Styling */
    .empty-state {
        text-align: center;
        padding: var(--space-16) var(--space-8);
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 2px dashed rgba(255, 255, 255, 0.3);
        border-radius: 24px;
        margin: var(--space-8) 0;
        animation: float 6s ease-in-out infinite;
    }
    
    .empty-icon {
        font-size: var(--text-6xl);
        margin-bottom: var(--space-4);
        opacity: 0.6;
        animation: pulse 3s ease-in-out infinite;
    }
    
    .empty-title {
        font-size: var(--text-2xl);
        font-weight: 700;
        color: var(--gray-700);
        margin-bottom: var(--space-2);
    }
    
    .empty-subtitle {
        font-size: var(--text-lg);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    /* Trade Summary Dashboard */
    .trade-summary-dashboard {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: var(--space-6);
        margin: var(--space-8) 0;
        padding: var(--space-6);
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 24px;
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-slow) var(--bounce);
    }
    
    .summary-card {
        display: flex;
        align-items: center;
        gap: var(--space-4);
        padding: var(--space-6);
        background: rgba(255, 255, 255, 0.9);
        border-radius: 20px;
        box-shadow: var(--shadow-lg);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        transform-style: preserve-3d;
    }
    
    .summary-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(249, 115, 22, 0.1), transparent);
        transition: left var(--transition-slow);
    }
    
    .summary-card:hover::before {
        left: 100%;
    }
    
    .summary-card:hover {
        transform: translateY(-5px) rotateX(10deg) rotateY(10deg) scale(1.05);
        box-shadow: var(--shadow-2xl), 0 0 30px rgba(249, 115, 22, 0.3);
    }
    
    .summary-icon {
        font-size: var(--text-4xl);
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
        animation: pulse 3s ease-in-out infinite;
    }
    
    .summary-content {
        flex: 1;
    }
    
    .summary-value {
        font-size: var(--text-3xl);
        font-weight: 800;
        color: var(--primary-600);
        line-height: 1;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .summary-label {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: var(--space-1);
    }
    
    /* Advanced Features Panel */
    .advanced-features-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 24px;
        padding: var(--space-8);
        margin: var(--space-8) 0;
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-slow) var(--bounce);
        position: relative;
        overflow: hidden;
    }
    
    .advanced-features-panel::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 0deg, transparent, rgba(16, 185, 129, 0.1), transparent);
        animation: rotate 30s linear infinite;
        pointer-events: none;
    }
    
    .advanced-features-panel h3 {
        font-size: var(--text-2xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-6);
        text-align: center;
        position: relative;
        z-index: 2;
    }
    
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: var(--space-6);
        position: relative;
        z-index: 2;
    }
    
    .feature-card {
        display: flex;
        align-items: center;
        gap: var(--space-4);
        padding: var(--space-6);
        background: rgba(255, 255, 255, 0.9);
        border-radius: 20px;
        box-shadow: var(--shadow-lg);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        transform-style: preserve-3d;
    }
    
    .feature-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left var(--transition-slow);
    }
    
    .feature-card:hover::before {
        left: 100%;
    }
    
    .feature-card:hover {
        transform: translateY(-8px) rotateX(10deg) rotateY(10deg) scale(1.05);
        box-shadow: var(--shadow-2xl), 0 0 40px rgba(249, 115, 22, 0.4);
    }
    
    .feature-icon {
        font-size: var(--text-3xl);
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
        animation: pulse 4s ease-in-out infinite;
    }
    
    .feature-content {
        flex: 1;
    }
    
    .feature-title {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-1);
    }
    
    .feature-desc {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    /* Main Section Container with Advanced Styling */
    .main-section-container {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 24px;
        padding: var(--space-8);
        margin: var(--space-8) 0;
        box-shadow: var(--shadow-xl);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-slow) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .main-section-container::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        animation: rotate 40s linear infinite;
        pointer-events: none;
    }
    
    .main-section-container:hover {
        transform: translateY(-5px) rotateX(2deg) rotateY(2deg);
        box-shadow: var(--shadow-2xl), 0 0 50px rgba(249, 115, 22, 0.3);
    }
    
    .section-badge {
        position: absolute;
        top: -12px;
        left: var(--space-6);
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-2) var(--space-6);
        border-radius: 20px;
        font-size: var(--text-sm);
        font-weight: 700;
        box-shadow: var(--shadow-lg);
        z-index: 10;
        animation: pulse 3s ease-in-out infinite;
    }
    
    .section-glow {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: radial-gradient(circle at center, rgba(249, 115, 22, 0.1) 0%, transparent 70%);
        pointer-events: none;
        animation: pulse 4s ease-in-out infinite;
    }
    
    /* Section Separator with Animation */
    .section-separator {
        display: flex;
        align-items: center;
        justify-content: center;
        margin: var(--space-12) 0;
        position: relative;
    }
    
    .separator-line {
        flex: 1;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--primary-500), transparent);
        position: relative;
        overflow: hidden;
    }
    
    .separator-line::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.8), transparent);
        animation: shimmer 3s ease-in-out infinite;
    }
    
    .separator-icon {
        font-size: var(--text-2xl);
        margin: 0 var(--space-6);
        background: var(--gradient-primary);
        color: white;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-xl);
        animation: pulse 2s ease-in-out infinite;
        position: relative;
        z-index: 2;
    }
    
    .separator-icon::before {
        content: '';
        position: absolute;
        top: -4px;
        left: -4px;
        right: -4px;
        bottom: -4px;
        background: linear-gradient(45deg, var(--primary-500), var(--secondary-500));
        border-radius: 50%;
        z-index: -1;
        animation: rotate 10s linear infinite;
    }
        border-top: none;
        padding: var(--space-6);
        box-shadow: var(--shadow-sm);
    }
    
    /* Professional Sidebar */
    .css-1d391kg, .css-1lcbmhc {
        background: var(--gradient-glass);
        backdrop-filter: blur(20px);
        border-right: 3px solid var(--secondary-500);
        box-shadow: var(--shadow-xl);
    }
    
    /* Section Headers */
    .section-header {
        font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        font-size: var(--text-2xl);
        font-weight: 700;
        color: var(--gray-800);
        margin: var(--space-8) 0 var(--space-6) 0;
        padding-bottom: var(--space-3);
        position: relative;
        animation: slideInLeft var(--transition-normal) var(--bounce);
    }
    
    .section-header::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 60px;
        height: 4px;
        background: var(--gradient-primary);
        border-radius: 2px;
        animation: expandWidth var(--transition-slow) var(--bounce) 0.2s;
    }
    
    /* Typography */
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        color: var(--gray-800);
        font-weight: 600;
        line-height: 1.3;
    }
    
    p, div, span, .stMarkdown {
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        color: var(--gray-700);
        line-height: 1.6;
    }
    
    /* Professional JSON Display */
    .stJson {
        background: var(--gradient-card);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        font-family: 'JetBrains Mono', 'Courier New', monospace;
        padding: var(--space-4);
        box-shadow: var(--shadow-md);
        font-size: var(--text-sm);
    }
    
    /* Trade Cards Enhanced */
    .trade-card-enhanced {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: var(--radius-2xl);
        padding: var(--space-6);
        margin: var(--space-4) 0;
        box-shadow: var(--shadow-xl);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-normal) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .trade-card-enhanced::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .trade-card-enhanced:hover::before {
        left: 100%;
    }
    
    .trade-card-enhanced:hover {
        transform: translateY(-8px) scale(1.02) rotateX(5deg);
        box-shadow: var(--shadow-2xl), var(--shadow-glow);
    }
    
    .trade-card-enhanced.profitable {
        border-left: 4px solid var(--secondary-500);
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-card-enhanced.moderate {
        border-left: 4px solid var(--primary-500);
        background: linear-gradient(135deg, rgba(249, 115, 22, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-card-enhanced.loss {
        border-left: 4px solid var(--rose-500);
        background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trade-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .trade-product {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
    }
    
    .trade-status {
        padding: var(--space-1) var(--space-3);
        border-radius: var(--radius-full);
        font-size: var(--text-xs);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .trade-status.profitable {
        background: var(--gradient-secondary);
        color: white;
    }
    
    .trade-status.moderate {
        background: var(--gradient-primary);
        color: white;
    }
    
    .trade-status.loss {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .trade-metrics {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: var(--space-3);
        margin-bottom: var(--space-4);
    }
    
    .metric {
        text-align: center;
        padding: var(--space-3);
        background: rgba(255, 255, 255, 0.5);
        border-radius: var(--radius-lg);
        transition: all var(--transition-normal);
    }
    
    .metric:hover {
        background: rgba(255, 255, 255, 0.8);
        transform: scale(1.05);
    }
    
    .metric-value {
        display: block;
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--primary-600);
    }
    
    .metric-unit {
        font-size: var(--text-xs);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    .trade-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: var(--space-3);
        border-top: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    .trade-time {
        font-size: var(--text-sm);
        color: var(--gray-600);
    }
    
    .profit-indicator {
        padding: var(--space-1) var(--space-3);
        border-radius: var(--radius-full);
        font-size: var(--text-sm);
        font-weight: 600;
        background: var(--gradient-secondary);
        color: white;
    }
    
    /* Empty State Styling */
    .empty-state {
        text-align: center;
        padding: var(--space-12) var(--space-6);
        background: var(--gradient-card);
        border-radius: var(--radius-2xl);
        border: 2px dashed rgba(249, 115, 22, 0.3);
        margin: var(--space-6) 0;
        animation: fadeIn 0.6s ease-out;
    }
    
    .empty-icon {
        font-size: 4rem;
        margin-bottom: var(--space-4);
        opacity: 0.6;
        animation: float 3s ease-in-out infinite;
    }
    
    .empty-title {
        font-size: var(--text-2xl);
        font-weight: 700;
        color: var(--gray-700);
        margin-bottom: var(--space-2);
    }
    
    .empty-subtitle {
        font-size: var(--text-lg);
        color: var(--gray-500);
        font-weight: 500;
    }
    
    @keyframes fadeIn {
        0% { opacity: 0; transform: translateY(20px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes float {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
    }
    
    /* Trade Cards */
    .trade-card {
        background: var(--gradient-card);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        padding: var(--space-6);
        margin: var(--space-4) 0;
        box-shadow: var(--shadow-lg);
        border-left: 4px solid var(--primary-500);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .trade-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        transition: left var(--transition-normal);
    }
    
    .trade-card:hover::before {
        left: 100%;
    }
    
    .trade-card:hover {
        transform: translateY(-4px) scale(1.01);
        box-shadow: var(--shadow-2xl), var(--shadow-glow);
    }
    
    /* Language Selector */
    .stSelectbox > div > div {
        background: rgba(255, 255, 255, 0.95) !important;
        backdrop-filter: blur(10px);
        border: 2px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px;
        transition: all var(--transition-normal);
        box-shadow: var(--shadow-md);
    }
    
    .stSelectbox > div > div:focus-within {
        border-color: var(--primary-500) !important;
        box-shadow: 0 0 0 3px rgba(249, 115, 22, 0.1), var(--shadow-lg);
        transform: translateY(-1px);
        background: rgba(255, 255, 255, 1) !important;
    }
    
    /* Language Selector Text */
    .stSelectbox > div > div > div {
        color: var(--gray-800) !important;
        font-weight: 600 !important;
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif !important;
    }
    
    /* Language Selector Options */
    .stSelectbox > div > div > div > div {
        color: var(--gray-800) !important;
        background: rgba(255, 255, 255, 0.98) !important;
        font-weight: 500 !important;
    }
    
    /* Language Selector Dropdown */
    .stSelectbox [data-baseweb="select"] > div {
        background: rgba(255, 255, 255, 0.95) !important;
        color: var(--gray-800) !important;
        font-weight: 600 !important;
        border: 2px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
    }
    
    /* Language Selector Dropdown Options */
    .stSelectbox [role="listbox"] {
        background: rgba(255, 255, 255, 0.98) !important;
        backdrop-filter: blur(20px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
        box-shadow: var(--shadow-xl) !important;
    }
    
    .stSelectbox [role="option"] {
        color: var(--gray-800) !important;
        font-weight: 500 !important;
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif !important;
        padding: var(--space-3) var(--space-4) !important;
        transition: all var(--transition-fast) !important;
    }
    
    .stSelectbox [role="option"]:hover {
        background: var(--gradient-primary) !important;
        color: white !important;
        font-weight: 600 !important;
    }
    
    .stSelectbox [aria-selected="true"] {
        background: var(--gradient-secondary) !important;
        color: white !important;
        font-weight: 700 !important;
    }
    
    /* Professional Footer */
    .footer-container {
        text-align: center;
        padding: var(--space-12) var(--space-8);
        margin-top: var(--space-16);
        background: var(--gradient-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 24px;
        color: var(--gray-800);
        box-shadow: var(--shadow-2xl);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-slow) var(--bounce);
    }
    
    .footer-container::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 180deg, transparent, rgba(16, 185, 129, 0.1), transparent);
        animation: rotate 25s linear infinite reverse;
        pointer-events: none;
    }
    
    .footer-text {
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
        font-weight: 500;
        position: relative;
        z-index: 2;
    }
    
    /* Professional Loading Spinner */
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s ease-in-out infinite;
    }
    
    /* Professional Animations */
    @keyframes slideInDown {
        from {
            opacity: 0;
            transform: translateY(-30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-30px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(30px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes expandWidth {
        from {
            width: 0;
        }
        to {
            width: 60px;
        }
    }
    
    @keyframes textGlow {
        from {
            text-shadow: 0 0 20px rgba(249, 115, 22, 0.5);
        }
        to {
            text-shadow: 0 0 40px rgba(249, 115, 22, 0.8), 0 0 60px rgba(16, 185, 129, 0.3);
        }
    }
    
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
            transform: scale(1);
        }
        50% {
            opacity: 0.8;
            transform: scale(1.05);
        }
    }
    
    @keyframes processing {
        0%, 100% {
            opacity: 1;
        }
        25% {
            opacity: 0.7;
        }
        50% {
            opacity: 1;
        }
        75% {
            opacity: 0.7;
        }
    }
    
    @keyframes rotate {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }
    
    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .app-title {
            font-size: var(--text-3xl);
        }
        
        .app-subtitle {
            font-size: var(--text-lg);
        }
        
        .main .block-container {
            padding: var(--space-4) var(--space-2);
        }
        
        .stButton > button {
            font-size: var(--text-sm);
            padding: var(--space-3) var(--space-6);
            min-height: 48px;
        }
        
        .header-container {
            padding: var(--space-8) var(--space-4);
        }
        
        .main-card {
            padding: var(--space-6);
        }
    }
    
    @media (max-width: 480px) {
        .app-title {
            font-size: var(--text-2xl);
        }
        
        .section-header {
            font-size: var(--text-xl);
        }
        
        .main-card {
            padding: var(--space-4);
        }
    }
    
    /* Accessibility */
    .stButton > button:focus {
        outline: 3px solid var(--blue-500);
        outline-offset: 2px;
    }
    
    /* High Contrast Mode */
    @media (prefers-contrast: high) {
        :root {
            --primary-500: #CC5500;
            --secondary-500: #006600;
            --gray-800: #000000;
            --gray-700: #333333;
        }
    }
    
    /* Reduced Motion */
    @media (prefers-reduced-motion: reduce) {
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
        
        .stButton > button:hover,
        .trade-card:hover,
        .main-card:hover {
            transform: none;
        }
    }
    
    /* Dark Mode Support */
    @media (prefers-color-scheme: dark) {
        :root {
            --gray-50: #1F2937;
            --gray-100: #374151;
            --gray-200: #4B5563;
            --gray-700: #E5E7EB;
            --gray-800: #F9FAFB;
        }
        
        .stApp {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        }
        
        .main-card,
        .trade-card {
            background: linear-gradient(145deg, rgba(31, 41, 55, 0.9), rgba(55, 65, 81, 0.7));
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    }
    
    /* Trade Summary Dashboard */
    .trade-summary-dashboard {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: var(--space-4);
        margin: var(--space-6) 0;
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .summary-card {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        padding: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-3);
        box-shadow: var(--shadow-lg);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        border-left: 4px solid var(--primary-500);
    }
    
    .summary-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .summary-card:hover::before {
        left: 100%;
    }
    
    .summary-card:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-xl), 0 0 20px rgba(249, 115, 22, 0.3);
    }
    
    .summary-icon {
        font-size: var(--text-2xl);
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        animation: pulse 3s ease-in-out infinite;
    }
    
    .summary-content {
        flex: 1;
    }
    
    .summary-value {
        font-size: var(--text-lg);
        font-weight: 800;
        color: var(--primary-600);
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    }
    
    .summary-label {
        font-size: var(--text-xs);
        color: var(--gray-600);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    /* Enhanced Trade Cards */
    .trade-card-enhanced {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-4) 0;
        box-shadow: var(--shadow-xl);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-normal) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .trade-card-enhanced::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-slow);
    }
    
    .trade-card-enhanced::after {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        border-radius: 22px;
        z-index: -1;
        opacity: 0;
        transition: opacity var(--transition-normal);
    }
    
    .trade-card-enhanced.profitable {
        border-left: 4px solid var(--secondary-500);
    }
    
    .trade-card-enhanced.profitable::after {
        background: linear-gradient(45deg, var(--secondary-500), var(--emerald-500));
    }
    
    .trade-card-enhanced.moderate {
        border-left: 4px solid var(--primary-500);
    }
    
    .trade-card-enhanced.moderate::after {
        background: linear-gradient(45deg, var(--primary-500), var(--primary-600));
    }
    
    .trade-card-enhanced.loss {
        border-left: 4px solid var(--rose-500);
    }
    
    .trade-card-enhanced.loss::after {
        background: linear-gradient(45deg, var(--rose-500), var(--pink-500));
    }
    
    .trade-card-enhanced:hover::before {
        left: 100%;
    }
    
    .trade-card-enhanced:hover::after {
        opacity: 0.3;
    }
    
    .trade-card-enhanced:hover {
        transform: translateY(-6px) rotateX(5deg) rotateY(5deg) scale(1.02);
        box-shadow: var(--shadow-2xl), 0 0 30px rgba(249, 115, 22, 0.4);
    }
    
    .trade-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .trade-product {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .trade-status {
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-xs);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        box-shadow: var(--shadow-sm);
    }
    
    .trade-card-enhanced.profitable .trade-status {
        background: var(--gradient-secondary);
        color: white;
    }
    
    .trade-card-enhanced.moderate .trade-status {
        background: var(--gradient-primary);
        color: white;
    }
    
    .trade-card-enhanced.loss .trade-status {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .trade-metrics {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .metric {
        text-align: center;
        padding: var(--space-3);
        background: rgba(255, 255, 255, 0.5);
        border-radius: 12px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        transition: all var(--transition-normal);
    }
    
    .metric:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
        background: rgba(255, 255, 255, 0.7);
    }
    
    .metric-value {
        display: block;
        font-size: var(--text-lg);
        font-weight: 800;
        color: var(--primary-600);
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    }
    
    .metric-unit {
        font-size: var(--text-xs);
        color: var(--gray-600);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .trade-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: var(--space-3);
        border-top: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    .trade-time {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    .profit-indicator {
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-sm);
        font-weight: 700;
        box-shadow: var(--shadow-sm);
    }
    
    .trade-card-enhanced.profitable .profit-indicator {
        background: var(--gradient-secondary);
        color: white;
    }
    
    .trade-card-enhanced.moderate .profit-indicator {
        background: var(--gradient-primary);
        color: white;
    }
    
    .trade-card-enhanced.loss .profit-indicator {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    /* Empty State */
    .empty-state {
        text-align: center;
        padding: var(--space-12) var(--space-8);
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 2px dashed rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        margin: var(--space-6) 0;
        animation: slideInUp var(--transition-normal) var(--bounce);
        transition: all var(--transition-normal);
    }
    
    .empty-state:hover {
        border-color: var(--primary-500);
        background: rgba(255, 255, 255, 0.9);
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
    }
    
    .empty-icon {
        font-size: var(--text-6xl);
        margin-bottom: var(--space-4);
        opacity: 0.6;
        animation: float 4s ease-in-out infinite;
    }
    
    .empty-title {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-700);
        margin-bottom: var(--space-2);
    }
    
    .empty-subtitle {
        font-size: var(--text-base);
        color: var(--gray-600);
        font-weight: 500;
        line-height: 1.6;
    }
    
    /* Analytics Content Styles - Fixed Layout */
    .analytics-content {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-4) 0;
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        width: 100%;
        max-width: 100%;
    }
    
    .analytics-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
        padding-bottom: var(--space-3);
        border-bottom: 2px solid var(--primary-500);
    }
    
    .analytics-title {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin: 0;
    }
    
    .analytics-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: var(--space-3);
        margin-bottom: var(--space-4);
    }
    
    .analytics-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 12px;
        padding: var(--space-4);
        box-shadow: var(--shadow-md);
        border-left: 3px solid var(--primary-500);
        transition: all var(--transition-normal);
        text-align: center;
        min-height: 120px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }
    
    .analytics-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
    }
    
    .analytics-card h4 {
        color: var(--gray-800);
        margin-bottom: var(--space-2);
        font-size: var(--text-sm);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .analytics-value {
        font-size: var(--text-2xl);
        font-weight: 800;
        color: var(--primary-600);
        margin-bottom: var(--space-1);
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        line-height: 1.2;
    }
    
    .analytics-description {
        color: var(--gray-600);
        font-size: var(--text-xs);
        font-weight: 500;
        line-height: 1.3;
    }
    
    /* Advanced Features Panel */
    .advanced-features-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        margin: var(--space-6) 0;
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        position: relative;
        overflow: hidden;
    }
    
    .advanced-features-panel::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.1), transparent);
        transition: left var(--transition-slow);
    }
    
    .advanced-features-panel:hover::before {
        left: 100%;
    }
    
    .advanced-features-panel h3 {
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        font-size: var(--text-xl);
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: var(--space-4);
    }
    
    .feature-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-3);
        box-shadow: var(--shadow-md);
        transition: all var(--transition-normal);
        border-left: 4px solid var(--blue-500);
        position: relative;
        overflow: hidden;
    }
    
    .feature-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.1), transparent);
        transition: left var(--transition-normal);
    }
    
    .feature-card:hover::before {
        left: 100%;
    }
    
    .feature-card:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-xl);
        border-left-color: var(--primary-500);
    }
    
    .feature-icon {
        font-size: var(--text-2xl);
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        animation: pulse 3s ease-in-out infinite;
    }
    
    .feature-title {
        font-weight: 700;
        color: var(--gray-800);
        font-size: var(--text-base);
        margin-bottom: var(--space-1);
    }
    
    .feature-desc {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    /* Prediction Panel */
    .prediction-panel {
        background: var(--gradient-card);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .prediction-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .prediction-header h4 {
        color: var(--gray-800);
        font-size: var(--text-lg);
        font-weight: 700;
        margin: 0;
    }
    
    .ai-status-badge {
        background: var(--gradient-secondary);
        color: white;
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        font-size: var(--text-xs);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        animation: pulse 2s ease-in-out infinite;
        box-shadow: var(--shadow-sm);
    }
    
    /* Trends Panel */
    .trends-panel {
        background: var(--gradient-card);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .trend-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .trend-header h4 {
        color: var(--gray-800);
        font-size: var(--text-lg);
        font-weight: 700;
        margin: 0;
    }
    
    .update-time {
        color: var(--gray-600);
        font-size: var(--text-sm);
        font-weight: 500;
        background: rgba(255, 255, 255, 0.7);
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        box-shadow: var(--shadow-sm);
    }
    
    .trend-item {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 12px;
        padding: var(--space-3);
        margin-bottom: var(--space-3);
        box-shadow: var(--shadow-sm);
        transition: all var(--transition-normal);
        border-left: 4px solid var(--primary-500);
    }
    
    .trend-item:hover {
        transform: translateX(5px);
        box-shadow: var(--shadow-md);
    }
    
    .trend-item.trending-up {
        border-left-color: var(--secondary-500);
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trend-item.trending-down {
        border-left-color: var(--rose-500);
        background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(255, 255, 255, 0.9));
    }
    
    .trend-product {
        font-weight: 700;
        color: var(--gray-800);
        font-size: var(--text-base);
        margin-bottom: var(--space-1);
    }
    
    .trend-change {
        font-weight: 700;
        font-size: var(--text-lg);
        margin-bottom: var(--space-1);
    }
    
    .trending-up .trend-change {
        color: var(--secondary-600);
    }
    
    .trending-down .trend-change {
        color: var(--rose-600);
    }
    
    .trend-reason {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
    }
    
    /* Voice Simulator */
    .voice-simulator {
        background: var(--gradient-card);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-4);
    }
    
    .voice-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
    }
    
    .voice-header h4 {
        color: var(--gray-800);
        font-size: var(--text-lg);
        font-weight: 700;
        margin: 0;
    }
    
    .voice-status {
        color: var(--secondary-600);
        font-size: var(--text-sm);
        font-weight: 600;
        background: rgba(16, 185, 129, 0.1);
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        border: 1px solid var(--secondary-500);
        animation: pulse 2s ease-in-out infinite;
    }
    
    .ai-response {
        background: var(--gradient-secondary);
        color: white;
        border-radius: 16px;
        padding: var(--space-4);
        box-shadow: var(--shadow-lg);
        animation: slideInRight var(--transition-normal) var(--bounce);
        position: relative;
        overflow: hidden;
    }
    
    .ai-response::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .ai-response:hover::before {
        left: 100%;
    }
    
    .response-text {
        font-size: var(--text-base);
        font-weight: 500;
        line-height: 1.6;
        margin-bottom: var(--space-4);
        white-space: pre-line;
    }
    
    .response-actions {
        display: flex;
        gap: var(--space-3);
        justify-content: center;
    }
    
    .action-btn {
        background: rgba(255, 255, 255, 0.2);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-2) var(--space-4);
        font-size: var(--text-sm);
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-normal);
        backdrop-filter: blur(10px);
    }
    
    .action-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }
    
    .ai-waiting {
        text-align: center;
        padding: var(--space-8);
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        border: 2px dashed var(--gray-300);
        animation: pulse 2s ease-in-out infinite;
    }
    
    .waiting-icon {
        font-size: var(--text-4xl);
        margin-bottom: var(--space-3);
        opacity: 0.6;
        animation: float 3s ease-in-out infinite;
    }
    
    .waiting-text {
        color: var(--gray-600);
        font-size: var(--text-base);
        font-weight: 500;
    }
    
    /* Advanced Animations */
    @keyframes fadeIn {
        from {
            opacity: 0;
        }
        to {
            opacity: 1;
        }
    }
    
    @keyframes scaleIn {
        from {
            opacity: 0;
            transform: scale(0.8);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }
    
    /* FULL-SPACE LAYOUT STYLES - For Analytics and Features */
    
    /* Main Section Container for Top-Down Layout */
    .main-section-container {
        width: 100%;
        max-width: 100%;
        margin: var(--space-6) 0;
        padding: var(--space-6);
        background: var(--gradient-card);
        border-radius: var(--radius-xl);
        box-shadow: var(--shadow-xl);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        position: relative;
        overflow: hidden;
        animation: slideInUp 0.6s var(--bounce);
        transform-style: preserve-3d;
        transition: all var(--transition-normal);
    }
    
    .main-section-container:hover {
        transform: translateY(-2px) scale(1.001);
        box-shadow: var(--shadow-2xl), var(--shadow-glow);
        border-color: rgba(249, 115, 22, 0.3);
    }
    
    .main-section-container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: var(--gradient-primary);
        border-radius: var(--radius-xl) var(--radius-xl) 0 0;
        animation: shimmer 2s infinite;
    }
    
    .main-section-container::after {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 0deg, transparent, rgba(249, 115, 22, 0.1), transparent);
        animation: rotate 10s linear infinite;
        pointer-events: none;
        z-index: -1;
    }
    
    /* Advanced Section Animations */
    @keyframes slideInUp {
        0% {
            opacity: 0;
            transform: translateY(30px) rotateX(10deg);
        }
        100% {
            opacity: 1;
            transform: translateY(0) rotateX(0deg);
        }
    }
    
    @keyframes shimmer {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }
    
    @keyframes rotate {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Advanced Page Transition */
    .page-transition-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: linear-gradient(135deg, var(--primary-600), var(--secondary-600));
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        transition: opacity 0.5s ease-out;
    }
    
    .transition-loader {
        text-align: center;
        color: white;
    }
    
    .loader-ring {
        width: 60px;
        height: 60px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top: 4px solid white;
        border-radius: 50%;
        margin: 0 auto 20px;
        animation: spin 1s linear infinite;
    }
    
    .loader-text {
        font-size: var(--text-lg);
        font-weight: 600;
        opacity: 0.9;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Section Badges */
    .section-badge {
        position: absolute;
        top: -12px;
        left: 30px;
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-2) var(--space-4);
        border-radius: var(--radius-full);
        font-size: var(--text-sm);
        font-weight: 600;
        box-shadow: var(--shadow-lg);
        z-index: 10;
        animation: pulse 2s infinite;
    }
    
    .section-glow {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(249, 115, 22, 0.1) 0%, transparent 70%);
        transform: translate(-50%, -50%);
        animation: breathe 4s ease-in-out infinite;
        pointer-events: none;
        z-index: -1;
    }
    
    @keyframes breathe {
        0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.5; }
        50% { transform: translate(-50%, -50%) scale(1.1); opacity: 0.8; }
    }
    
    /* Animated Section Separator */
    .section-separator {
        display: flex;
        align-items: center;
        justify-content: center;
        margin: var(--space-8) 0;
        position: relative;
    }
    
    .separator-line {
        flex: 1;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--primary-500), transparent);
        animation: flow 3s ease-in-out infinite;
    }
    
    .separator-icon {
        margin: 0 var(--space-4);
        font-size: var(--text-2xl);
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: bounce 2s infinite;
    }
    
    @keyframes flow {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 1; }
    }
    
    @keyframes bounce {
        0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
        40% { transform: translateY(-10px); }
        60% { transform: translateY(-5px); }
    }
    
    /* Full-Screen Feature Container */
    .feature-fullscreen {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: var(--bg-enterprise);
        z-index: 9999;
        overflow-y: auto;
        padding: var(--space-6);
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .feature-fullscreen::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: 
            radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%);
        pointer-events: none;
        z-index: -1;
    }
    
    /* Full-Screen Feature Header */
    .feature-header-full {
        background: var(--gradient-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 24px;
        padding: var(--space-8);
        margin-bottom: var(--space-6);
        text-align: center;
        position: relative;
        overflow: hidden;
        box-shadow: var(--shadow-2xl);
        animation: slideInDown var(--transition-slow) var(--bounce);
    }
    
    .feature-header-full::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
        animation: rotate 20s linear infinite;
        pointer-events: none;
    }
    
    .feature-header-full h2 {
        font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        font-size: clamp(var(--text-2xl), 4vw, var(--text-4xl));
        font-weight: 800;
        background: var(--gradient-hero);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: var(--space-3);
        position: relative;
        z-index: 2;
        text-shadow: 0 0 30px rgba(249, 115, 22, 0.5);
        animation: textGlow 3s ease-in-out infinite alternate;
    }
    
    .feature-header-full p {
        font-size: var(--text-lg);
        font-weight: 500;
        color: rgba(255, 255, 255, 0.9);
        position: relative;
        z-index: 2;
        margin-bottom: var(--space-4);
    }
    
    /* Full-Screen Status Badges */
    .ai-status-badge-full,
    .update-badge-full,
    .voice-status-badge-full {
        background: var(--gradient-secondary);
        color: white;
        padding: var(--space-2) var(--space-4);
        border-radius: 25px;
        font-size: var(--text-sm);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        animation: pulse 2s ease-in-out infinite;
        box-shadow: var(--shadow-lg);
        display: inline-block;
        position: relative;
        z-index: 2;
    }
    
    .update-badge-full {
        background: var(--gradient-primary);
    }
    
    .voice-status-badge-full {
        background: linear-gradient(135deg, var(--blue-500), var(--indigo-500));
    }
    
    /* Full-Width Analytics Container */
    .analytics-fullscreen {
        width: 100%;
        max-width: 100%;
        margin: 0;
        padding: 0;
    }
    
    .analytics-header-full {
        background: var(--gradient-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 20px;
        padding: var(--space-6);
        margin-bottom: var(--space-6);
        text-align: center;
        box-shadow: var(--shadow-xl);
        animation: slideInDown var(--transition-normal) var(--bounce);
    }
    
    .analytics-header-full h2 {
        font-size: var(--text-3xl);
        font-weight: 800;
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: var(--space-2);
    }
    
    .analytics-header-full p {
        color: rgba(255, 255, 255, 0.9);
        font-size: var(--text-lg);
        font-weight: 500;
    }
    
    /* Full-Width Analytics Cards */
    .analytics-card-full {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        transition: all var(--transition-normal);
        text-align: center;
        position: relative;
        overflow: hidden;
        animation: slideInUp var(--transition-normal) var(--bounce);
        transform-style: preserve-3d;
    }
    
    .analytics-card-full::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .analytics-card-full:hover::before {
        left: 100%;
    }
    
    .analytics-card-full:hover {
        transform: translateY(-5px) rotateX(5deg) rotateY(5deg) scale(1.02);
        box-shadow: var(--shadow-2xl), 0 0 30px rgba(249, 115, 22, 0.4);
    }
    
    .analytics-card-full .card-icon {
        font-size: var(--text-4xl);
        margin-bottom: var(--space-3);
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
        animation: pulse 3s ease-in-out infinite;
    }
    
    .analytics-card-full h3 {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-2);
    }
    
    .analytics-card-full .card-value {
        font-size: var(--text-3xl);
        font-weight: 800;
        color: var(--primary-600);
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-bottom: var(--space-2);
    }
    
    .analytics-card-full .card-desc {
        color: var(--gray-600);
        font-size: var(--text-sm);
        font-weight: 500;
    }
    
    /* Full-Width Prediction Table */
    .prediction-table {
        width: 100%;
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--shadow-xl);
        margin: var(--space-6) 0;
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .prediction-header-row {
        display: grid;
        grid-template-columns: 2fr 1.5fr 1.5fr 1fr 1fr 1.5fr;
        gap: var(--space-2);
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-4);
        font-weight: 700;
        font-size: var(--text-sm);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .prediction-row {
        display: grid;
        grid-template-columns: 2fr 1.5fr 1.5fr 1fr 1fr 1.5fr;
        gap: var(--space-2);
        padding: var(--space-4);
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        transition: all var(--transition-normal);
        align-items: center;
    }
    
    .prediction-row:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: translateX(5px);
    }
    
    .prediction-row:last-child {
        border-bottom: none;
    }
    
    .pred-product {
        font-weight: 700;
        color: var(--gray-800);
        font-size: var(--text-base);
    }
    
    .pred-current,
    .pred-predicted {
        font-weight: 600;
        color: var(--gray-700);
        font-size: var(--text-base);
    }
    
    .pred-change {
        font-weight: 700;
        font-size: var(--text-base);
        padding: var(--space-1) var(--space-2);
        border-radius: 12px;
        text-align: center;
    }
    
    .pred-change.positive {
        background: linear-gradient(135deg, var(--secondary-500), var(--emerald-500));
        color: white;
    }
    
    .pred-change.negative {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .pred-change.neutral {
        background: linear-gradient(135deg, var(--gray-400), var(--gray-500));
        color: white;
    }
    
    .pred-confidence {
        font-weight: 600;
        padding: var(--space-1) var(--space-2);
        border-radius: 12px;
        text-align: center;
    }
    
    .pred-confidence.high {
        background: linear-gradient(135deg, var(--secondary-500), var(--emerald-500));
        color: white;
    }
    
    .pred-confidence.medium {
        background: linear-gradient(135deg, var(--primary-500), var(--primary-600));
        color: white;
    }
    
    .pred-confidence.low {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .pred-recommendation {
        font-weight: 700;
        padding: var(--space-1) var(--space-3);
        border-radius: 20px;
        text-align: center;
        font-size: var(--text-sm);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .pred-recommendation.buy {
        background: var(--gradient-secondary);
        color: white;
    }
    
    .pred-recommendation.sell {
        background: linear-gradient(135deg, var(--rose-500), var(--pink-500));
        color: white;
    }
    
    .pred-recommendation.hold {
        background: linear-gradient(135deg, var(--blue-500), var(--indigo-500));
        color: white;
    }
    
    /* Full-Width AI Insights Panels */
    .ai-insights-panel,
    .trading-strategy-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        height: 100%;
    }
    
    .ai-insights-panel h4,
    .trading-strategy-panel h4 {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .ai-insights-list,
    .strategy-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .ai-insights-list li,
    .strategy-list li {
        background: rgba(255, 255, 255, 0.7);
        border-radius: 12px;
        padding: var(--space-4);
        margin-bottom: var(--space-3);
        border-left: 4px solid var(--primary-500);
        transition: all var(--transition-normal);
        font-size: var(--text-base);
        line-height: 1.6;
    }
    
    .ai-insights-list li:hover,
    .strategy-list li:hover {
        transform: translateX(5px);
        box-shadow: var(--shadow-md);
        background: rgba(255, 255, 255, 0.9);
    }
    
    .ai-insights-list li strong,
    .strategy-list li strong {
        color: var(--primary-600);
        font-weight: 700;
    }
    
    /* Full-Width Trend Sections */
    .trend-section {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        height: 100%;
    }
    
    .trending-up-section {
        border-left: 4px solid var(--secondary-500);
    }
    
    .trending-down-section {
        border-left: 4px solid var(--rose-500);
    }
    
    .stable-section {
        border-left: 4px solid var(--blue-500);
    }
    
    .trend-section h3 {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .trend-item-full {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-3);
        box-shadow: var(--shadow-md);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
    }
    
    .trend-item-full::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left var(--transition-normal);
    }
    
    .trend-item-full:hover::before {
        left: 100%;
    }
    
    .trend-item-full:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-xl);
    }
    
    .trend-item-full.trending-up {
        border-left: 4px solid var(--secondary-500);
    }
    
    .trend-item-full.trending-down {
        border-left: 4px solid var(--rose-500);
    }
    
    .trend-item-full.stable {
        border-left: 4px solid var(--blue-500);
    }
    
    .trend-product-name {
        font-size: var(--text-lg);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-2);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .trend-change-value {
        font-size: var(--text-xl);
        font-weight: 800;
        margin-bottom: var(--space-2);
    }
    
    .trend-item-full.trending-up .trend-change-value {
        color: var(--secondary-600);
    }
    
    .trend-item-full.trending-down .trend-change-value {
        color: var(--rose-600);
    }
    
    .trend-item-full.stable .trend-change-value {
        color: var(--blue-600);
    }
    
    .trend-reason-text {
        font-size: var(--text-sm);
        color: var(--gray-600);
        font-weight: 500;
        margin-bottom: var(--space-2);
        line-height: 1.5;
    }
    
    .trend-volume {
        font-size: var(--text-xs);
        color: var(--gray-500);
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    /* Full-Width Market Alerts */
    .market-alert-full {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-3);
        display: flex;
        align-items: center;
        gap: var(--space-4);
        box-shadow: var(--shadow-lg);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        animation: slideInLeft var(--transition-normal) var(--bounce);
    }
    
    .market-alert-full::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .market-alert-full:hover::before {
        left: 100%;
    }
    
    .market-alert-full:hover {
        transform: translateX(5px) scale(1.01);
        box-shadow: var(--shadow-xl);
    }
    
    .market-alert-full.opportunity {
        border-left: 4px solid var(--secondary-500);
    }
    
    .market-alert-full.warning {
        border-left: 4px solid var(--primary-500);
    }
    
    .market-alert-full.info {
        border-left: 4px solid var(--blue-500);
    }
    
    .market-alert-full .alert-icon {
        font-size: var(--text-2xl);
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        animation: pulse 2s ease-in-out infinite;
    }
    
    .market-alert-full .alert-content {
        flex: 1;
    }
    
    .market-alert-full .alert-message {
        font-size: var(--text-base);
        font-weight: 600;
        color: var(--gray-800);
        line-height: 1.5;
        margin-bottom: var(--space-1);
    }
    
    .market-alert-full .alert-priority {
        font-size: var(--text-sm);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .market-alert-full.opportunity .alert-priority,
    .market-alert-full.opportunity.high .alert-priority {
        color: var(--secondary-600);
    }
    
    .market-alert-full.warning .alert-priority,
    .market-alert-full.warning.medium .alert-priority {
        color: var(--primary-600);
    }
    
    .market-alert-full.info .alert-priority,
    .market-alert-full.info.low .alert-priority {
        color: var(--blue-600);
    }
    
    /* Full-Width Voice Interface */
    .voice-commands-section,
    .ai-response-section {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        height: 100%;
    }
    
    .voice-commands-section h3,
    .ai-response-section h3 {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .voice-command-card {
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        padding: var(--space-4);
        margin-bottom: var(--space-3);
        box-shadow: var(--shadow-md);
        transition: all var(--transition-normal);
        position: relative;
        overflow: hidden;
        border-left: 4px solid var(--primary-500);
    }
    
    .voice-command-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left var(--transition-normal);
    }
    
    .voice-command-card:hover::before {
        left: 100%;
    }
    
    .voice-command-card:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: var(--shadow-xl);
    }
    
    .voice-command-card.trade {
        border-left-color: var(--secondary-500);
    }
    
    .voice-command-card.query {
        border-left-color: var(--blue-500);
    }
    
    .voice-command-card.sell {
        border-left-color: var(--rose-500);
    }
    
    .voice-command-card.analysis {
        border-left-color: var(--purple-500);
    }
    
    .voice-command-card.weather {
        border-left-color: var(--cyan-500);
    }
    
    .voice-command-card.calculation {
        border-left-color: var(--indigo-500);
    }
    
    .command-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-2);
    }
    
    .command-lang {
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-1) var(--space-2);
        border-radius: 12px;
        font-size: var(--text-xs);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .command-type {
        background: var(--gradient-secondary);
        color: white;
        padding: var(--space-1) var(--space-2);
        border-radius: 12px;
        font-size: var(--text-xs);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .command-text {
        font-size: var(--text-base);
        font-weight: 600;
        color: var(--gray-800);
        line-height: 1.5;
        font-family: 'Inter', 'Noto Sans Devanagari', sans-serif;
    }
    
    /* Full-Width AI Response */
    .ai-response-full {
        background: var(--gradient-secondary);
        color: white;
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        animation: slideInRight var(--transition-normal) var(--bounce);
        position: relative;
        overflow: hidden;
        margin-bottom: var(--space-4);
    }
    
    .ai-response-full::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
        transition: left var(--transition-normal);
    }
    
    .ai-response-full:hover::before {
        left: 100%;
    }
    
    .response-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: var(--space-4);
        padding-bottom: var(--space-3);
        border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    }
    
    .response-status {
        font-size: var(--text-base);
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .response-time {
        font-size: var(--text-sm);
        font-weight: 500;
        opacity: 0.8;
    }
    
    .response-content {
        margin-bottom: var(--space-4);
    }
    
    .response-text {
        font-size: var(--text-base);
        font-weight: 500;
        line-height: 1.6;
        white-space: pre-line;
    }
    
    .response-actions-full {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: var(--space-3);
    }
    
    .action-btn-full {
        background: rgba(255, 255, 255, 0.2);
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        padding: var(--space-3) var(--space-4);
        font-size: var(--text-sm);
        font-weight: 600;
        cursor: pointer;
        transition: all var(--transition-normal);
        backdrop-filter: blur(10px);
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: var(--space-2);
    }
    
    .action-btn-full:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }
    
    .action-btn-full.confirm {
        background: rgba(16, 185, 129, 0.3);
        border-color: var(--secondary-500);
    }
    
    .action-btn-full.reject {
        background: rgba(244, 63, 94, 0.3);
        border-color: var(--rose-500);
    }
    
    .action-btn-full.retry {
        background: rgba(59, 130, 246, 0.3);
        border-color: var(--blue-500);
    }
    
    .action-btn-full.save {
        background: rgba(139, 92, 246, 0.3);
        border-color: var(--purple-500);
    }
    
    /* Full-Width AI Waiting State */
    .ai-waiting-full {
        text-align: center;
        padding: var(--space-12);
        background: rgba(255, 255, 255, 0.9);
        border-radius: 20px;
        border: 2px dashed var(--gray-300);
        animation: pulse 2s ease-in-out infinite;
        box-shadow: var(--shadow-lg);
    }
    
    .waiting-animation {
        position: relative;
        display: inline-block;
        margin-bottom: var(--space-4);
    }
    
    .pulse-circle {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 80px;
        height: 80px;
        border: 3px solid var(--secondary-500);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        animation: pulse 2s ease-in-out infinite;
        opacity: 0.6;
    }
    
    .waiting-icon {
        font-size: var(--text-5xl);
        position: relative;
        z-index: 2;
        animation: float 3s ease-in-out infinite;
    }
    
    .waiting-text {
        color: var(--gray-700);
        font-size: var(--text-xl);
        font-weight: 700;
        margin-bottom: var(--space-2);
    }
    
    .waiting-subtitle {
        color: var(--gray-600);
        font-size: var(--text-base);
        font-weight: 500;
    }
    
    /* Full-Width Product Performance Table */
    .product-performance-table {
        width: 100%;
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--shadow-xl);
        margin: var(--space-6) 0;
        animation: slideInUp var(--transition-normal) var(--bounce);
    }
    
    .table-header {
        display: grid;
        grid-template-columns: 0.5fr 2fr 1fr 1.5fr 2fr 1.5fr;
        gap: var(--space-2);
        background: var(--gradient-primary);
        color: white;
        padding: var(--space-4);
        font-weight: 700;
        font-size: var(--text-sm);
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .table-row {
        display: grid;
        grid-template-columns: 0.5fr 2fr 1fr 1.5fr 2fr 1.5fr;
        gap: var(--space-2);
        padding: var(--space-4);
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        transition: all var(--transition-normal);
        align-items: center;
    }
    
    .table-row:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: translateX(5px);
    }
    
    .table-row:last-child {
        border-bottom: none;
    }
    
    .cell-rank {
        font-size: var(--text-xl);
        text-align: center;
    }
    
    .cell-product {
        font-weight: 700;
        color: var(--gray-800);
        font-size: var(--text-base);
    }
    
    .cell-trades,
    .cell-quantity,
    .cell-value,
    .cell-avg {
        font-weight: 600;
        color: var(--gray-700);
        font-size: var(--text-base);
        text-align: center;
    }
    
    .cell-value {
        color: var(--primary-600);
        font-weight: 800;
    }
    
    /* Full-Width Insights and Recommendations */
    .insights-panel,
    .recommendations-panel {
        background: var(--gradient-card);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: var(--space-6);
        box-shadow: var(--shadow-xl);
        animation: slideInUp var(--transition-normal) var(--bounce);
        height: 100%;
    }
    
    .insights-panel h4,
    .recommendations-panel h4 {
        font-size: var(--text-xl);
        font-weight: 700;
        color: var(--gray-800);
        margin-bottom: var(--space-4);
        display: flex;
        align-items: center;
        gap: var(--space-2);
    }
    
    .insights-list,
    .recommendations-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .insights-list li,
    .recommendations-list li {
        background: rgba(255, 255, 255, 0.7);
        border-radius: 12px;
        padding: var(--space-4);
        margin-bottom: var(--space-3);
        border-left: 4px solid var(--primary-500);
        transition: all var(--transition-normal);
        font-size: var(--text-base);
        line-height: 1.6;
    }
    
    .insights-list li:hover,
    .recommendations-list li:hover {
        transform: translateX(5px);
        box-shadow: var(--shadow-md);
        background: rgba(255, 255, 255, 0.9);
    }
    
    .insights-list li strong,
    .recommendations-list li strong {
        color: var(--primary-600);
        font-weight: 700;
    }
    
    /* Responsive Full-Space Layout */
    @media (max-width: 768px) {
        .feature-fullscreen {
            padding: var(--space-4);
        }
        
        .feature-header-full {
            padding: var(--space-6);
        }
        
        .feature-header-full h2 {
            font-size: var(--text-2xl);
        }
        
        .analytics-card-full {
            padding: var(--space-4);
        }
        
        .prediction-header-row,
        .prediction-row {
            grid-template-columns: 1fr;
            gap: var(--space-1);
            text-align: center;
        }
        
        .table-header,
        .table-row {
            grid-template-columns: 1fr;
            text-align: center;
        }
        
        .response-actions-full {
            grid-template-columns: 1fr;
        }
    }
    
    /* Print Styles */
    @media print {
        .stButton,
        .status-indicator,
        .loading-spinner,
        .analytics-modal,
        .advanced-features-panel,
        .voice-simulator,
        .feature-fullscreen {
            display: none !important;
        }
        
        .main-card,
        .trade-card,
        .trade-card-enhanced {
            box-shadow: none;
            border: 1px solid #ccc;
        }
    }
    </style>
    """


def apply_viksit_bharat_theme():
    """Apply the Viksit Bharat theme to the Streamlit application."""
    
    # Inject custom CSS
    st.markdown(get_viksit_bharat_css(), unsafe_allow_html=True)
    
    # Configure Streamlit theme colors
    st.markdown("""
    <script>
    // Set CSS custom properties for dynamic theming
    document.documentElement.style.setProperty('--primary-color', '#FF9933');
    document.documentElement.style.setProperty('--secondary-color', '#138808');
    document.documentElement.style.setProperty('--background-color', '#FFFFFF');
    </script>
    """, unsafe_allow_html=True)


def get_theme_colors() -> Dict[str, str]:
    """Get the theme color palette."""
    
    return {
        'saffron': '#FF9933',
        'green': '#138808',
        'white': '#FFFFFF',
        'navy_blue': '#000080',
        'light_saffron': '#FFB366',
        'light_green': '#4CAF50',
        'text_dark': '#2E2E2E',
        'text_light': '#666666',
        'border_color': '#E0E0E0'
    }


def ensure_accessibility():
    """Ensure the theme meets accessibility standards."""
    
    # Add ARIA labels and roles for better screen reader support
    st.markdown("""
    <script>
    // Add ARIA labels to buttons
    document.addEventListener('DOMContentLoaded', function() {
        const buttons = document.querySelectorAll('.stButton > button');
        buttons.forEach(button => {
            if (!button.getAttribute('aria-label')) {
                button.setAttribute('aria-label', button.textContent);
            }
        });
        
        // Add role attributes to main sections
        const mainContainer = document.querySelector('.main');
        if (mainContainer) {
            mainContainer.setAttribute('role', 'main');
        }
        
        // Add landmark roles
        const sidebar = document.querySelector('.css-1d391kg');
        if (sidebar) {
            sidebar.setAttribute('role', 'complementary');
            sidebar.setAttribute('aria-label', 'Trade Ledger Sidebar');
        }
    });
    </script>
    """, unsafe_allow_html=True)


def load_regional_fonts():
    """Load fonts that support regional Indian scripts."""
    
    # Fonts are loaded via CSS @import in get_viksit_bharat_css()
    # This function can be extended to load additional fonts dynamically
    pass


class ThemeManager:
    """Theme manager class for centralized theme operations."""
    
    def __init__(self):
        self.colors = get_theme_colors()
        self.applied = False
    
    def apply_theme(self):
        """Apply the complete Viksit Bharat theme."""
        if not self.applied:
            apply_viksit_bharat_theme()
            ensure_accessibility()
            load_regional_fonts()
            self.applied = True
    
    def get_color(self, color_name: str) -> str:
        """Get a specific theme color."""
        return self.colors.get(color_name, '#000000')
    
    def get_gradient(self, start_color: str, end_color: str) -> str:
        """Generate a CSS gradient string."""
        start = self.get_color(start_color)
        end = self.get_color(end_color)
        return f"linear-gradient(135deg, {start}, {end})"