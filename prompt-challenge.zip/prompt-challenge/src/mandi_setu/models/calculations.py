"""
Mathematical calculation functions for Mandi-Setu trade operations.

This module provides functions for calculating trade amounts, taxes, and fees
with proper rounding and validation according to Indian market standards.
"""

from decimal import Decimal, ROUND_HALF_UP
from typing import Union


def calculate_total_amount(quantity: Union[float, Decimal], unit_price: Union[float, Decimal]) -> float:
    """
    Calculate total amount from quantity and unit price.
    
    Args:
        quantity: Quantity of the product (must be positive)
        unit_price: Price per unit in INR (must be positive)
        
    Returns:
        Total amount (quantity × unit_price) rounded to 2 decimal places
        
    Raises:
        ValueError: If quantity or unit_price is not positive
    """
    if quantity <= 0:
        raise ValueError(f"Quantity must be positive, got {quantity}")
    if unit_price <= 0:
        raise ValueError(f"Unit price must be positive, got {unit_price}")
    
    # Use Decimal for precise calculation
    qty_decimal = Decimal(str(quantity))
    price_decimal = Decimal(str(unit_price))
    
    total = qty_decimal * price_decimal
    
    # Round to 2 decimal places using banker's rounding
    rounded_total = total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    
    return float(rounded_total)


def calculate_mandi_cess(total_amount: Union[float, Decimal]) -> float:
    """
    Calculate 5% Mandi Cess on the total amount.
    
    Args:
        total_amount: Total trade amount in INR (must be non-negative)
        
    Returns:
        Mandi cess (5% of total_amount) rounded to 2 decimal places
        
    Raises:
        ValueError: If total_amount is negative
    """
    if total_amount < 0:
        raise ValueError(f"Total amount must be non-negative, got {total_amount}")
    
    # Use Decimal for precise calculation
    amount_decimal = Decimal(str(total_amount))
    cess_rate = Decimal('0.05')  # 5%
    
    cess = amount_decimal * cess_rate
    
    # Round to 2 decimal places using banker's rounding
    rounded_cess = cess.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    
    return float(rounded_cess)


def calculate_final_amount(quantity: Union[float, Decimal], unit_price: Union[float, Decimal]) -> tuple[float, float, float]:
    """
    Calculate complete trade amounts including total and cess.
    
    Args:
        quantity: Quantity of the product (must be positive)
        unit_price: Price per unit in INR (must be positive)
        
    Returns:
        Tuple of (total_amount, mandi_cess, final_amount_with_cess)
        
    Raises:
        ValueError: If quantity or unit_price is not positive
    """
    total_amount = calculate_total_amount(quantity, unit_price)
    mandi_cess = calculate_mandi_cess(total_amount)
    final_amount = total_amount + mandi_cess
    
    return total_amount, mandi_cess, final_amount


def validate_calculation_consistency(quantity: Union[float, Decimal], 
                                   unit_price: Union[float, Decimal],
                                   total_amount: Union[float, Decimal],
                                   mandi_cess: Union[float, Decimal]) -> bool:
    """
    Validate that provided amounts are mathematically consistent.
    
    Args:
        quantity: Quantity of the product
        unit_price: Price per unit in INR
        total_amount: Claimed total amount
        mandi_cess: Claimed mandi cess
        
    Returns:
        True if all calculations are consistent, False otherwise
    """
    try:
        expected_total = calculate_total_amount(quantity, unit_price)
        expected_cess = calculate_mandi_cess(expected_total)
        
        # Allow for small floating point differences (1 paisa tolerance)
        total_diff = abs(float(total_amount) - expected_total)
        cess_diff = abs(float(mandi_cess) - expected_cess)
        
        return total_diff <= 0.01 and cess_diff <= 0.01
        
    except (ValueError, TypeError):
        return False