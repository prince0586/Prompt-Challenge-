"""
Core data models for Mandi-Setu.

This module contains the primary data models used throughout the application,
including TradeData and DigitalParchi models with proper validation.
"""

from datetime import datetime
from typing import Optional
from uuid import uuid4
from enum import Enum

from pydantic import BaseModel, Field


class ParchiStatus(str, Enum):
    """Status enumeration for Digital Parchi."""
    DRAFT = "DRAFT"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class TradeData(BaseModel):
    """
    Represents extracted trade information from negotiations.
    
    This model contains all the essential trade details extracted from
    voice conversations, including product information, quantities, and pricing.
    """
    product_name: str = Field(..., min_length=1, description="Name of the traded product")
    quantity: float = Field(..., gt=0, description="Quantity of the product")
    unit: str = Field(..., min_length=1, description="Unit of measurement (kg, quintal, piece, etc.)")
    unit_price: float = Field(..., gt=0, description="Price per unit in INR")
    total_amount: float = Field(..., gt=0, description="Total amount before cess (quantity × unit_price)")
    mandi_cess: float = Field(..., ge=0, description="5% cess automatically calculated")
    timestamp: datetime = Field(default_factory=datetime.now, description="Transaction timestamp")
    language: str = Field(..., min_length=2, max_length=10, description="Detected language code")
    conversation_id: str = Field(default_factory=lambda: str(uuid4()), description="Unique conversation identifier")


class DigitalParchi(BaseModel):
    """
    Complete digital trade receipt with metadata.
    
    This model represents the final digital receipt generated after
    successful trade negotiations, containing all trade data plus
    additional metadata for tracking and audit purposes.
    """
    id: str = Field(default_factory=lambda: str(uuid4()), description="Unique parchi identifier")
    trade_data: TradeData = Field(..., description="Embedded trade information")
    vendor_id: Optional[str] = Field(None, description="Optional vendor identification")
    status: ParchiStatus = Field(default=ParchiStatus.COMPLETED, description="Current parchi status")
    created_at: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    updated_at: datetime = Field(default_factory=datetime.now, description="Last update timestamp")