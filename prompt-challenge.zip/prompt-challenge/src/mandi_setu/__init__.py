"""
Mandi-Setu: Multilingual AI Assistant for Agricultural Markets

A voice-first AI assistant designed for local vendors in Indian agricultural markets.
Supports multilingual negotiations, automatic data extraction, and digital documentation.
"""

__version__ = "1.0.0"
__author__ = "Mandi-Setu Development Team"